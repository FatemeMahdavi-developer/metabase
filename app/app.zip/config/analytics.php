<?php

return [
    'displays' => ['number', 'bar', 'line', 'area', 'pie', 'doughnut', 'scatter', 'table', 'pivot', 'funnel', 'progress', 'gauge'],
    'operators' => ['eq', 'neq', 'in', 'not_in', 'contains', 'not_contains', 'starts_with', 'ends_with', 'between', 'not_between', 'gt', 'lt', 'gte', 'lte', 'is_null', 'not_null', 'is_empty', 'not_empty'],
    'cache_seconds' => 30,
    'preview_row_limit' => 2000,
    'preview_aggregate_limit' => 10000,
];
