<x-filament-panels::page>
    @vite(['resources/css/analytics.css', 'resources/js/analytics.js'])
    <div id="analytics-studio" wire:ignore data-api="{{ url('/analytics/api') }}" data-user="{{ auth()->id() }}" data-csrf="{{ csrf_token() }}" data-preview-row-limit="{{ config('analytics.preview_row_limit') }}" data-preview-aggregate-limit="{{ config('analytics.preview_aggregate_limit') }}" data-section="{{ $analyticsSection }}" data-record="{{ $analyticsRecord }}" data-routes='@json($analyticsRoutes)' data-initial='@json($analyticsInitial)'>
        <div data-analytics-content>
            <div class="mb-loading">در حال آماده‌سازی فضای تحلیل…</div>
        </div>
        @include('filament.partials.analytics-modal')
    </div>
</x-filament-panels::page>
