{{-- Keep the native Alpine modal lifecycle outside the JavaScript workbench renderer. --}}
<div data-analytics-modal-host>
    @foreach (['dialog' => false, 'slide-over' => true] as $variant => $slideOver)
        <x-filament::modal
            :id="'analytics-'.$variant"
            :slide-over="$slideOver"
            :width="$slideOver ? 'xl' : '3xl'"
            :sticky-header="true"
            :sticky-footer="true"
            :close-by-clicking-away="true"
            :extra-modal-window-attribute-bag="new \Illuminate\View\ComponentAttributeBag(['data-analytics-modal-window' => $variant])"
            :aria-labelledby="'analytics-'.$variant.'-heading'"
        >
            <x-slot name="heading">
                <span id="analytics-{{ $variant }}-heading" data-analytics-modal-title></span>
            </x-slot>

            <form id="analytics-{{ $variant }}-form" class="fi-fo analytics-workbench-form" data-analytics-modal-form onsubmit="return false">
                <div class="mb-dialog-body" data-analytics-modal-body></div>
                <div class="mb-dialog-error" role="alert" aria-live="polite"></div>
            </form>

            <x-slot name="footer">
                <div class="fi-modal-footer-actions mb-dialog-footer" data-analytics-modal-footer></div>
            </x-slot>
        </x-filament::modal>
    @endforeach
</div>

{{-- Render these controls through Filament, then clone their markup for notebook fields. --}}
@foreach (['primary', 'gray', 'danger', 'success'] as $color)
    <template id="analytics-native-button-{{ $color }}">
        <x-filament::button :color="$color" :loading-indicator="false"> </x-filament::button>
    </template>
@endforeach
<template id="analytics-native-input-wrapper">
    <x-filament::input.wrapper>
        <span data-analytics-input-slot></span>
    </x-filament::input.wrapper>
</template>
<template id="analytics-native-input"><x-filament::input /></template>
<template id="analytics-native-checkbox"><x-filament::input.checkbox /></template>
<template id="analytics-native-radio"><x-filament::input.radio /></template>
<template id="analytics-native-select"><x-filament::input.select /></template>
