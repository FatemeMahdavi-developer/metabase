let fallbackSequence = 0;

// These IDs identify UI items; they are not authentication tokens or secrets.
export function uid() {
    const crypto = globalThis.crypto;
    if (typeof crypto?.randomUUID === 'function') return crypto.randomUUID();

    const bytes = new Uint8Array(16);
    if (typeof crypto?.getRandomValues === 'function') {
        crypto.getRandomValues(bytes);
    } else {
        for (let index = 0; index < bytes.length; index++) bytes[index] = Math.floor(Math.random() * 256);

        let timestamp = Date.now();
        let sequence = ++fallbackSequence;
        for (let index = 0; index < 6; index++) {
            bytes[index] ^= (timestamp % 256) ^ (sequence % 256);
            bytes[10 + index] = sequence % 256;
            timestamp = Math.floor(timestamp / 256);
            sequence = Math.floor(sequence / 256);
        }
    }

    bytes[6] = (bytes[6] & 0x0f) | 0x40;
    bytes[8] = (bytes[8] & 0x3f) | 0x80;
    const hex = Array.from(bytes, byte => byte.toString(16).padStart(2, '0')).join('');
    return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}
