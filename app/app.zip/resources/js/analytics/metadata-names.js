import { options } from './ui';
import { validMetadataLanguage, projectMetadataNames, normalizeMetadataSearch } from './metadata-labels';
import '../../css/analytics-names.css';

const languageChoices = compact => [{ key: 'original', label: compact ? 'DB' : 'نام اصلی دیتابیس' }, { key: 'fa', label: compact ? 'FA' : 'فارسی' }, { key: 'en', label: compact ? 'EN' : 'English' }];

export const metadataNameMethods = {
    initializeMetadataNames() {
        this.metadataLanguageStorageKey = 'analytics-metadata-language:' + (this.root.dataset.user || 'guest');
        let stored;
        try { stored = window.localStorage.getItem(this.metadataLanguageStorageKey); } catch {}
        this.metadataLanguage = validMetadataLanguage(stored) ? stored : 'original';
        this.root.dataset.metadataLanguage = this.metadataLanguage;
    },
    projectMetadataNames(value) { return projectMetadataNames(value, this.metadataLanguage); },
    metadataLanguageControlHtml(picker = false) {
        const compact = !picker && window.innerWidth < 768;
        const choices = languageChoices(compact);
        const id = 'analytics-metadata-language-' + (picker ? 'picker' : 'global');
        return `<label class="mb-metadata-language ${compact ? 'compact' : ''}" for="${id}"><span>نام جدول‌ها و ستون‌ها</span><select class="mb-input" id="${id}" aria-label="زبان نام جدول‌ها و ستون‌ها" title="زبان نام جدول‌ها و ستون‌ها" data-metadata-language>${options(choices, this.metadataLanguage)}</select></label>`;
    },
    refreshMetadataLanguageControls() {
        const select = this.root.querySelector('#analytics-metadata-language-global');
        if (!select) return;
        const label = select.closest('.mb-metadata-language');
        const compact = window.innerWidth < 768;
        if (label.classList.contains('compact') === compact) return;
        label.classList.toggle('compact', compact);
        select.innerHTML = options(languageChoices(compact), this.metadataLanguage);
    },
    changeMetadataLanguage(target) {
        if (!validMetadataLanguage(target.value) || target.value === this.metadataLanguage) return;
        const picker = target.closest('.mb-dialog')?.querySelector('.mb-data-picker');
        const search = picker?.querySelector('[data-picker-search]')?.value || '';
        this.metadataLanguage = target.value;
        this.root.dataset.metadataLanguage = this.metadataLanguage;
        try { window.localStorage.setItem(this.metadataLanguageStorageKey, this.metadataLanguage); } catch {}
        for (const property of ['library', 'browserConnection', 'previewResult', 'report', 'reportOriginal', 'dashboard', 'savedDashboard', 'stepPreviewResults', 'drillSession', 'objectDetailFrame']) {
            if (this[property]) this[property] = this.projectMetadataNames(this[property]);
        }
        for (const [key, result] of this.results) this.results.set(key, this.projectMetadataNames(result));
        for (const [key, cached] of this.cardCache) this.cardCache.set(key, { ...cached, result: this.projectMetadataNames(cached.result) });
        if (picker) {
            this.metadataNamesPendingRender = true;
            this.sourcePickerDialog();
            const input = this.root.querySelector('.mb-dialog [data-picker-search]');
            if (input) {
                input.value = search;
                this.root.querySelectorAll('.mb-dialog .mb-card-picker').forEach(row => { row.hidden = !(row.dataset.searchText || normalizeMetadataSearch(row.textContent)).includes(normalizeMetadataSearch(search)); });
            }
            this.root.querySelector('.mb-dialog [data-metadata-language]')?.focus();
        } else {
            this.render();
            this.root.querySelector('#analytics-metadata-language-global')?.focus({ preventScroll: true });
        }
    },
};
