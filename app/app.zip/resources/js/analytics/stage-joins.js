import { e, copy, uid, icon, button, iconButton, field, input } from './ui';
import { joinedMetadataField } from './metadata-labels';

export const stageAdditionalMethods = {
    stageAvailableFields(joins = this.stageDraft.joins || [], includeExpressions = true) {
        const fields = copy(this.stageFields);
        const connection = this.library.connections.find(row => row.id === this.report.query_definition.connection_id);
        for (const join of joins) {
            const table = connection.catalog.find(row => row.key === join.source);
            for (const column of table?.fields || []) fields.push(joinedMetadataField(column, table, join.alias + '.' + column.key, this.metadataLanguage));
        }
        if (includeExpressions) for (const expression of this.stageDraft.expressions || []) fields.push({ key: expression.key, label: expression.label, type: expression.type || 'number', computed: true });
        return fields;
    },
    stageJoinsHtml(stage, index) {
        const connection = this.library.connections.find(row => row.id === this.report.query_definition.connection_id);
        return (stage.joins || []).map(join => `<div class="mb-step"><div class="mb-step-content"><div class="mb-step-label">اتصال داده‌ها</div><div class="mb-step-box">${button(this.joinIcon(join.type || 'left') + e(connection.catalog.find(row => row.key === join.source)?.label || join.source), 'editStage', 'mb-source-chip', `data-index="${index}"`)}<span class="mb-help">${e((join.type || 'left').toUpperCase())} JOIN · ${join.conditions.length} شرط</span></div></div></div>`).join('') + (stage.expressions?.length ? `<div class="mb-step"><div class="mb-step-content"><div class="mb-step-label">ستون محاسباتی</div><div class="mb-step-box">${stage.expressions.map(expression => button(e(expression.label), 'editStage', 'mb-notebook-chip blue', `data-index="${index}"`)).join('')}</div></div></div>` : '');
    },
    stageConnectionsHtml() {
        const stage = this.stageDraft;
        const connection = this.library.connections.find(row => row.id === this.report.query_definition.connection_id);
        return `<div class="mb-stage-form"><strong>اتصال نتیجه به جدول دیگر</strong><div class="mb-query-chips">${(stage.joins || []).map((join, index) => `<span class="mb-chip">${button(this.joinIcon(join.type) + e(connection.catalog.find(row => row.key === join.source)?.label || join.source), 'editStageJoin', 'small', `data-index="${index}"`)}${iconButton('close', 'حذف اتصال و اتصال‌های بعدی', 'removeStageJoin', `data-index="${index}"`)}</span>`).join('')}${stage.joins.length < 5 ? button(icon('join') + 'اتصال جدول', 'addStageJoin', 'small') : ''}</div><strong>ستون‌های محاسباتی</strong><div class="mb-query-chips">${(stage.expressions || []).map((expression, index) => `<span class="mb-chip">${button(e(expression.label), 'editStageExpression', 'small', `data-index="${index}"`)}${iconButton('close', 'حذف ستون', 'removeStageExpression', `data-index="${index}"`)}</span>`).join('')}${stage.expressions.length < 10 ? button(icon('plus') + 'ستون محاسباتی', 'addStageExpression', 'small') : ''}</div></div>`;
    },
    addStageJoin() {
        this.readStageForm();
        if (this.stageDraft.joins.length >= 5) throw new Error('حداکثر پنج اتصال در هر مرحله مجاز است.');
        const connection = this.library.connections.find(row => row.id === this.report.query_definition.connection_id);
        const fields = this.stageAvailableFields(this.stageDraft.joins, false);
        const table = connection.catalog[0];
        if (!table || !fields.length) throw new Error('جدول یا ستون قابل اتصال پیدا نشد.');
        const left = fields.find(row => row.type === table.fields[0]?.type) || fields[0];
        this.joinStage = true; this.joinIndex = -1;
        this.joinDraft = { source: table.key, alias: 'join_' + uid().replaceAll('-', '').slice(0, 8), type: 'left', conditions: [{ left: left.key, right: table.fields[0].key, operator: 'eq' }] };
        this.joinDialog();
    },
    editStageJoin(target) {
        this.readStageForm(); this.joinStage = true; this.joinIndex = Number(target.dataset.index);
        this.joinDraft = copy(this.stageDraft.joins[this.joinIndex]); this.joinDialog();
    },
    cancelStageJoin() { if (this.stageInline) { this.stageInline = false; this.closeModal(); } else this.stageDialog(); },
    async validateStageDraft(stage) {
        const query = copy(this.report.query_definition); query.stages ||= [];
        const index = this.stageIndex < 0 ? query.stages.length : this.stageIndex;
        query.stages[index] = stage;
        query.stages = query.stages.slice(0, index + 1);
        const result = await this.request('reports/preview', 'POST', { query_definition: query });
        return result.query_definition.stages[index];
    },
    async saveStageJoin() {
        const stage = copy(this.stageDraft);
        if (this.joinIndex < 0) stage.joins.push(copy(this.joinDraft)); else stage.joins[this.joinIndex] = copy(this.joinDraft);
        const available = this.stageAvailableFields(stage.joins);
        if (stage.mode === 'rows' && this.joinIndex < 0) stage.columns = [...new Set([...(stage.columns || []), ...available.filter(row => !row.hidden && row.key.startsWith(this.joinDraft.alias + '.')).map(row => row.key)])].slice(0, 50);
        this.pruneStageFields(stage, available);
        this.stageDraft = await this.validateStageDraft(stage); this.stageDraft.joins ||= []; this.stageDraft.expressions ||= [];
        if (this.stageInline) return this.commitNotebookDefinition(this.stageIndex + 1, this.stageDraft);
        this.stageDialog();
    },
    pruneStageFields(stage, fields) {
        const keys = fields.map(row => row.key);
        stage.columns = stage.columns?.filter(key => keys.includes(key));
        stage.filters = stage.filters.filter(row => keys.includes(row.field));
        stage.dimensions = stage.dimensions.filter(row => keys.includes(row.field));
        stage.metrics = stage.metrics.filter(row => row.function === 'count' || keys.includes(row.field));
        const outputs = stage.mode === 'rows' ? stage.columns || keys : [...stage.dimensions.map(row => row.field), ...stage.metrics.map(row => row.key)];
        stage.sort = stage.sort.filter(row => outputs.includes(row.key));
    },
    removeStageJoin(target) {
        this.readStageForm(); this.stageDraft.joins.splice(Number(target.dataset.index));
        this.pruneStageFields(this.stageDraft, this.stageAvailableFields()); this.stageDialog();
    },
    addStageExpression() { this.editStageExpression({ dataset: { index: -1 } }); },
    editStageExpression(target) {
        this.readStageForm(); this.stageExpressionIndex = Number(target.dataset.index);
        this.stageExpressionDraft = copy(this.stageDraft.expressions[this.stageExpressionIndex] || { key: 'custom_' + uid().replaceAll('-', '').slice(0, 8), label: '', expression: '' });
        const expression = this.stageExpressionDraft;
        this.modal('ستون محاسباتی روی نتیجهٔ قبلی', field('نام ستون', input('label', expression.label, 'text', 'maxlength="150"')) + field('فرمول', `<textarea class="mb-input mb-sql" name="expression">${e(expression.expression)}</textarea>`) + `<div class="mb-formula-fields">${this.stageAvailableFields().filter(row => row.key !== expression.key).map(row => `<button class="mb-badge" data-action="insertExpressionField" data-key="${e(row.key)}">${e(row.label)}</button>`).join('')}</div><p class="mb-help">ستون‌های مرحلهٔ قبلی و جدول‌های متصل‌شده قابل استفاده‌اند. توابع: abs، round، coalesce، concat، upper، lower، case و if.</p>`, button('انصراف', 'cancelStageJoin') + button('اعمال ستون', 'saveStageExpression', 'primary'), true);
    },
    async saveStageExpression() {
        const form = this.form(); const expression = { ...this.stageExpressionDraft, label: form.get('label'), expression: form.get('expression') };
        if (!expression.label.trim() || !expression.expression.trim()) throw new Error('نام و فرمول ستون را وارد کنید.');
        const stage = copy(this.stageDraft);
        if (this.stageExpressionIndex < 0) stage.expressions.push(expression); else stage.expressions[this.stageExpressionIndex] = expression;
        if (stage.mode === 'rows' && this.stageExpressionIndex < 0) stage.columns = [...(stage.columns || []), expression.key].slice(0, 50);
        this.stageDraft = await this.validateStageDraft(stage); this.stageDraft.joins ||= []; this.stageDraft.expressions ||= [];
        this.stageDialog();
    },
    removeStageExpression(target) {
        this.readStageForm(); this.stageDraft.expressions.splice(Number(target.dataset.index));
        this.pruneStageFields(this.stageDraft, this.stageAvailableFields()); this.stageDialog();
    },
};
