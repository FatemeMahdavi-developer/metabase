import { e, icon, button, field, input, options, tableHtml } from './ui';
import { metadataSearchText } from './metadata-labels';

export const connectionMethods = {
    newConnection() { this.connectionDialog(null); },
    editConnection(target) { this.connectionDialog(this.library.connections.find(row => row.id === Number(target.dataset.id))); },
    connectionDialog(connection) {
        this.navigationEpoch++;
        this.connectionDraft = connection;
        this.dirty = false; this.closeModal(); this.view = 'connection'; this.render();
    },
    connectionHtml() {
        const connection = this.connectionDraft;
        return `<header class="mb-toolbar"><div><div class="mb-breadcrumb">تنظیمات / پایگاه‌های داده</div><h1>${connection ? e(connection.name) : 'افزودن پایگاه داده'}</h1></div>${button('بازگشت به دیتابیس‌ها', 'cancelConnection')}</header><section class="mb-db-page"><form data-connection-form onsubmit="return false">${field('نوع دیتابیس', `<select class="mb-input" name="driver" data-driver>${options([{ key: 'sqlite', label: 'SQLite' }, { key: 'pgsql', label: 'PostgreSQL' }, { key: 'clickhouse', label: 'ClickHouse (HTTP)' }], connection?.driver || 'sqlite')}</select>`)}${field('نام نمایشی', input('name', connection?.name || '', 'text', 'required maxlength="150"'), 'نامی که هنگام انتخاب داده‌ها نمایش داده می‌شود.')}<div class="mb-connection-fields"></div><div class="mb-test-result" role="status"></div><div class="mb-dialog-error" aria-live="polite"></div><div class="mb-connection-footer">${button(connection ? 'ذخیرهٔ تغییرات' : 'ذخیره و همگام‌سازی', 'saveConnection', 'primary')}${button('آزمایش اتصال', 'testConnection')}${button('ذخیره بدون اتصال', 'saveConnectionOffline')}${button('انصراف', 'cancelConnection')}</div></form></section>`;
    },
    cancelConnection() {
        const leave = () => { this.navigationEpoch++; this.dirty = false; this.connectionDraft = null; this.view = 'connections'; this.render(); };
        if (this.dirty) this.confirm('تغییرات ذخیره‌نشده', 'ورودی‌های فرم کنار گذاشته شوند؟', leave); else leave();
    },
    connectionDriverChanged(target) {
        const driver = target.value; const config = this.connectionDraft?.driver === driver ? this.connectionDraft.configuration : {};
        this.root.querySelector('.mb-connection-fields').innerHTML = driver === 'sqlite' ?
            field('مسیر کامل فایل SQLite روی سرور', input('path', config.path || '', 'text', 'dir="ltr" required'), 'فایل باید از قبل وجود داشته باشد. اتصال فقط برای خواندن است.') :
            `<div class="mb-form-grid">${field('Host', input('host', config.host || 'localhost', 'text', 'dir="ltr"'))}${field('Port', input('port', config.port || (driver === 'pgsql' ? 5432 : 8123), 'number', 'min="1" max="65535"'))}</div>` +
            field('Database', input('database', config.database || '', 'text', 'dir="ltr"')) +
            field('Username', input('username', config.username || (driver === 'clickhouse' ? 'default' : ''), 'text', 'dir="ltr" autocomplete="off"')) +
            field('Password', input('password', '', 'password', 'dir="ltr" autocomplete="new-password"'), this.connectionDraft?.has_password ? 'خالی بگذارید تا رمز قبلی حفظ شود.' : 'رمز به‌صورت رمزگذاری‌شده ذخیره می‌شود.') +
            (driver === 'pgsql' ? field('SSL mode', `<select class="mb-input" name="sslmode">${options(['disable', 'prefer', 'require', 'verify-full'], config.sslmode || 'prefer')}</select>`) : `<label class="mb-inline-check">${input('ssl', '', 'checkbox', config.ssl ? 'checked' : '')}اتصال HTTPS</label>`) +
            '<p class="mb-help">برای ذخیرهٔ تنظیمات نیازی به نصب یا اجرای سرور دیتابیس نیست. آزمایش و همگام‌سازی به سرور قابل دسترس نیاز دارد.</p>';
    },
    connectionPayload() {
        const form = this.form(); const driver = form.get('driver'); const configuration = driver === 'sqlite' ? { path: form.get('path') } :
            { host: form.get('host'), port: Number(form.get('port')), database: form.get('database'), username: form.get('username'), ...(driver === 'pgsql' ? { sslmode: form.get('sslmode') } : { ssl: form.has('ssl') }) };
        if (driver !== 'sqlite' && (form.get('password') || !this.connectionDraft?.has_password)) configuration.password = form.get('password') || '';
        return { name: form.get('name'), driver, configuration };
    },
    async testConnection() {
        const payload = this.connectionPayload();
        const result = await this.request('connections/test', 'POST', { ...payload, ...(this.connectionDraft ? { connection_id: this.connectionDraft.id } : {}) });
        this.root.querySelector('.mb-test-result').textContent = `اتصال برقرار شد؛ ${result.table_count} جدول یا View پیدا شد.`;
    },
    async saveConnection() { await this.persistConnection(true); },
    async saveConnectionOffline() { await this.persistConnection(false); },
    async persistConnection(test) {
        await this.request(this.connectionDraft ? `connections/${this.connectionDraft.id}` : 'connections', this.connectionDraft ? 'PUT' : 'POST', { ...this.connectionPayload(), test_first: test });
        this.dirty = false; this.closeModal(); this.view = 'connections'; await this.refreshLibrary(); this.render(); this.toast('اتصال ذخیره شد.');
    },
    async browseConnection(target) {
        const opening = ++this.navigationEpoch;
        let connection = this.library.connections.find(row => row.id === Number(target.dataset.id));
        if (!connection.catalog) connection = await this.request(`connections/${connection.id}/sync`, 'POST', {});
        if (opening !== this.navigationEpoch) return;
        this.browserConnection = connection;
        this.library.connections = this.library.connections.map(row => row.id === connection.id ? connection : row);
        this.browserTable = this.browserConnection.catalog[0]?.key; this.view = 'browser'; this.render();
    },
    async syncConnection() { this.browserConnection = await this.request(`connections/${this.browserConnection.id}/sync`, 'POST', {}); await this.refreshLibrary(); if (!this.browserConnection.catalog.some(table => table.key === this.browserTable)) this.browserTable = this.browserConnection.catalog[0]?.key; this.render(); this.toast('ساختار دیتابیس همگام شد.'); },
    browserHtml() {
        const connection = this.browserConnection; const table = connection.catalog.find(row => row.key === this.browserTable);
        return `<header class="mb-toolbar"><div><div class="mb-breadcrumb">مرور داده‌ها</div><h1>${icon('database')} ${e(connection.name)}</h1></div><div class="mb-actions">${button(icon('settings') + 'تنظیم اتصال', 'editConnection', '', `data-id="${connection.id}"`)}${button(icon('refresh') + 'همگام‌سازی', 'syncConnection')}${table ? button('ساخت گزارش از این جدول', 'reportFromTable', 'primary') : ''}</div></header><div class="mb-content"><div class="mb-schema"><nav class="mb-schema-tables"><label class="mb-search">${icon('search')}<input placeholder="جست‌وجوی جدول…" aria-label="جست‌وجوی جدول" data-schema-search></label>${connection.catalog.map(row => `<button class="${row.key === this.browserTable ? 'active' : ''}" data-action="selectTable" data-key="${e(row.key)}" data-search-text="${e(metadataSearchText(row))}">${icon('table')} ${e(row.label || row.key)} ${row.kind === 'view' ? '<small>View</small>' : ''}</button>`).join('')}</nav><div class="mb-schema-details">${table ? `<div class="mb-schema-heading"><div><h2>${e(table.label || table.key)} <span class="mb-count">${table.fields.length} ستون</span></h2><p class="mb-help">${e(table.description)}</p></div>${button('تنظیم جدول', 'editDataMetadata', 'small')}</div><nav class="mb-browser-tabs"><button class="${this.browserMode !== 'data' ? 'active' : ''}" data-action="browserTab" data-tab="schema">ساختار داده‌ها</button><button class="${this.browserMode === 'data' ? 'active' : ''}" data-action="browserTab" data-tab="data">داده‌های جدول</button></nav>${this.browserMode !== 'data' ? `<table class="mb-table"><thead><tr><th>نام ستون</th><th>نوع داده</th><th>معنا</th><th>کلید / رابطه</th><th>مقدار خالی</th><th>نمایش</th><th></th></tr></thead><tbody>${table.fields.map(column => `<tr><td><strong>${e(column.label || column.key)}</strong><small class="mb-list-subtitle" dir="ltr"> ${column.label !== column.key ? e(column.key) : ''}</small></td><td dir="ltr">${e(column.raw_type)}</td><td>${e(column.semantic_type || '—')}</td><td>${column.primary ? '🔑 کلید اصلی' : ''}${column.relation ? ` → ${e(column.relation.table)}.${e(column.relation.field)}` : ''}</td><td>${column.nullable ? 'بله' : 'خیر'}</td><td>${column.hidden ? 'پنهان' : 'قابل نمایش'}</td><td>${button(icon('settings'), 'editDataMetadata', 'small', `data-key="${e(column.key)}" aria-label="تنظیم ستون ${e(column.label)}"`)}</td></tr>`).join('')}</tbody></table>` : `<div class="mb-actions">${button(icon('filter') + 'فیلتر', 'tableFilter')}${button(icon('chart') + 'خلاصه‌سازی', 'tableSummarize')}</div>`}<h3 style="margin:24px 0 12px;font-weight:bold">${this.browserMode === 'data' ? 'داده‌ها' : 'نمونهٔ داده'}</h3><div class="mb-browser-preview"><div class="mb-loading">در حال خواندن جدول…</div></div>` : '<div class="mb-empty">جدولی پیدا نشد.</div>'}</div></div></div>`;
    },
    selectTable(target) { this.browserTable = target.dataset.key; this.render(); },
    browserTab(target) { this.browserMode = target.dataset.tab; this.render(); },
    tableFilter() { this.reportFromTable(); this.addReportFilter(); },
    tableSummarize() { this.reportFromTable(); this.addMetric(); },
    async loadTablePreview() {
        if (!this.browserTable) return; const epoch = this.epoch;
        try { const result = await this.request('reports/preview', 'POST', { query_definition: { connection_id: this.browserConnection.id, source: this.browserTable, mode: 'rows', metrics: [], dimensions: [], filters: [], sort: [], joins: [], limit: 20 } }); if (epoch === this.epoch) this.root.querySelector('.mb-browser-preview').innerHTML = tableHtml(result); }
        catch (error) { if (epoch === this.epoch) this.root.querySelector('.mb-browser-preview').innerHTML = `<div class="mb-error">${e(error.message)}</div>`; }
    },
    reportFromTable() { this.createReport(this.browserConnection.id, this.browserTable); },
    editDataMetadata(target) {
        const table = this.browserConnection.catalog.find(row => row.key === this.browserTable);
        const column = target.dataset.key ? table.fields.find(row => row.key === target.dataset.key) : null;
        this.metadataField = column?.key || null;
        const row = column || table;
        const tableMetadata = this.browserConnection.metadata?.[table.key] || {};
        const custom = column ? tableMetadata.fields?.[column.key] || {} : tableMetadata;
        const name = language => Object.hasOwn(custom.labels || {}, language) ? custom.labels[language] || '' : row.display_names?.[language] !== row.display_names?.original ? row.display_names?.[language] || '' : '';
        const original = row.original_name || row.key;
        const names = field('نام اصلی دیتابیس', '<input class="mb-input" data-original-name value="' + e(original) + '" dir="auto" readonly>')
            + field('نام نمایشی فارسی', input('label_fa', name('fa'), 'text', 'maxlength="150" dir="auto"'))
            + field('نام نمایشی انگلیسی', input('label_en', name('en'), 'text', 'maxlength="150" dir="ltr"'))
            + '<p class="mb-help">خالی بودن نام نمایشی، نام اصلی دیتابیس را در آن زبان نشان می‌دهد. نام واقعی جدول یا ستون تغییر نمی‌کند.</p>';
        this.modal(column ? 'تنظیم ستون' : 'تنظیم جدول', names + field('توضیح', `<textarea class="mb-input" name="description" rows="3">${e(row.description)}</textarea>`) + (column ? field('معنای ستون', `<select class="mb-input" name="semantic_type">${options([{ key: 'category', label: 'دسته‌بندی' }, { key: 'name', label: 'نام' }, { key: 'currency', label: 'مبلغ' }, { key: 'quantity', label: 'تعداد' }, { key: 'percentage', label: 'درصد' }, { key: 'url', label: 'لینک' }, { key: 'email', label: 'ایمیل' }, { key: 'city', label: 'شهر' }, { key: 'country', label: 'کشور' }], column.semantic_type, 'بدون معنای خاص')}</select>`) + `<label class="mb-inline-check">${input('hidden', '', 'checkbox', column.hidden ? 'checked' : '')}پنهان در انتخاب پیش‌فرض ستون‌ها</label><p class="mb-help">شناسهٔ فنی ${e(column.key)} و نوع اصلی ${e(column.raw_type)} در دیتابیس حفظ می‌شوند.</p>` : ''), button('اعمال', 'saveDataMetadata', 'primary'));
    },
    async saveDataMetadata() {
        const form = this.form();
        this.browserConnection = await this.request(`connections/${this.browserConnection.id}/metadata`, 'PUT', {
            table: this.browserTable, field: this.metadataField,
            labels: { fa: String(form.get('label_fa') || '').trim() || null, en: String(form.get('label_en') || '').trim() || null },
            description: form.get('description'),
            ...(this.metadataField ? { hidden: form.has('hidden'), semantic_type: form.get('semantic_type') || null } : {}),
        });
        await this.refreshLibrary(); this.closeModal(); this.render(); this.toast('تنظیمات داده ذخیره شد.');
    },
};
