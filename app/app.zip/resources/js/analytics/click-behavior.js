import { e, copy, icon, button, iconButton, input, field, options } from './ui';
import { isCurrentFilamentModal } from './filament-modal';

const select = (items, value, attrs = '', placeholder = null) => `<select class="mb-input" ${attrs}>${options(items, value, placeholder)}</select>`;
const types = {
    menu: ['notebook', 'باز کردن منوی بررسی داده', 'فیلتر، مشاهدهٔ ردیف‌ها و بررسی بیشتر داده‌ها'],
    filter: ['filter', 'تغییر فیلترهای داشبورد', 'مقدار کلیک‌شده را به یک یا چند فیلتر متصل کنید'],
    dashboard: ['dashboard', 'رفتن به یک داشبورد', 'داشبورد مقصد را همراه با مقادیر فیلتر باز کنید'],
    report: ['chart', 'رفتن به یک پرسش ذخیره‌شده', 'پرسش مقصد را همراه با شرط‌های انتخاب‌شده باز کنید'],
    url: ['link', 'رفتن به یک آدرس اینترنتی', 'یک لینک با مقادیر ستون‌ها و فیلترها بسازید'],
    none: ['close', 'بدون عمل', 'کلیک روی این داده عملی انجام نمی‌دهد'],
};

function normalizeBehavior(behavior = {}, firstColumn = '') {
    const normalized = copy(behavior || {});
    normalized.type = !normalized.type || normalized.type === 'details' ? 'menu' : normalized.type;
    if (normalized.type === 'filter' && !normalized.mappings?.length && normalized.filter_key) {
        normalized.mappings = [{ target: normalized.filter_key, source: 'column', key: normalized.column || firstColumn }];
    }
    if (normalized.type === 'filter' && normalized.mappings?.length) { delete normalized.filter_key; delete normalized.column; }
    if (normalized.columns) normalized.columns = Object.fromEntries(Object.entries(normalized.columns).map(([key, value]) => [key, normalizeBehavior(value, key)]));
    return normalized;
}

export function resolveWidgetClickBehavior(widget, columnKey) {
    const behavior = widget.click_behavior || { type: 'menu' };
    return normalizeBehavior(behavior.columns?.[columnKey] || behavior, columnKey);
}

export function mappingSourceValue(mapping, row, context = {}) {
    if (mapping.source === 'parameter') return (context.parameters || context.appliedValues || {})[mapping.key];
    return row?.[mapping.key];
}

export function interpolateClickTemplate(template, row = {}, context = {}, settings = {}) {
    const encode = settings.encode !== false;
    return String(template || '').replace(/\{\{(column|parameter):([^{}]+)\}\}|\{\{value\}\}/g, (_, source, key) => {
        const value = source ? mappingSourceValue({ source, key: key.trim() }, row, context) : context.value ?? row[context.column_key];
        const text = value == null ? '' : Array.isArray(value) ? value.join(',') : typeof value === 'object' ? JSON.stringify(value) : String(value);
        return encode ? encodeURIComponent(text) : text;
    });
}

export function pruneClickFilterReferences(behavior, filterKey, dashboardId) {
    const normalized = copy(behavior || { type: 'menu' });
    const columns = normalized.columns;
    delete normalized.columns;
    if (normalized.mappings) {
        normalized.mappings = normalized.mappings.filter(mapping => !(mapping.source === 'parameter' && mapping.key === filterKey) && !((normalized.type === 'filter' || normalized.type === 'dashboard' && Number(normalized.dashboard_id) === Number(dashboardId)) && mapping.target === filterKey));
    }
    let clean = normalized;
    if (normalized.type === 'filter') {
        if (normalized.mappings?.length) { delete normalized.filter_key; delete normalized.column; }
        else if (normalized.filter_key === filterKey || !normalized.filter_key) clean = { type: 'none' };
    }
    const referencesParameter = template => [...String(template || '').matchAll(/\{\{parameter:([^{}]+)\}\}/g)].some(match => match[1].trim() === filterKey);
    if (normalized.type === 'url' && referencesParameter(normalized.url)) clean = { type: 'none' };
    else if (referencesParameter(normalized.link_text)) delete clean.link_text;
    if (columns) clean.columns = Object.fromEntries(Object.entries(columns).map(([key, nested]) => [key, pruneClickFilterReferences(nested, filterKey, dashboardId)]));
    return clean;
}

export const clickBehaviorMethods = {
    resolveWidgetClickBehavior,
    mappingSourceValue,
    interpolateClickTemplate,
    pruneClickFilterReferences,

    cardSettings(target) {
        const widget = this.dashboard.widgets.find(row => row.key === target.dataset.key);
        if (!widget) throw new Error('کارت پیدا نشد.');
        this.cardDraft = widget;
        if (widget.type !== 'report') {
            this.textDraft = widget;
            this.modal('تنظیم محتوای کارت', field('عنوان', input('title', widget.settings.title || '')) + field('محتوا', `<textarea class="mb-input" name="content" rows="8">${e(widget.content)}</textarea>`), button('ذخیره', widget.type === 'link' ? 'saveLinkCard' : 'saveTextCard', 'primary'));
            return;
        }
        this.cardSettingsTitleDraft = widget.settings.title || this.dashboardReport(widget.report_id).name;
        this.cardClickDraft = normalizeBehavior(widget.click_behavior, this.results.get(widget.key)?.columns[0]?.key);
        this.renderCardSettingsDialog();
    },

    renderCardSettingsDialog() {
        const behavior = this.cardClickDraft;
        const overrides = Object.keys(behavior.columns || {}).length;
        const summary = types[behavior.type]?.[1] || types.menu[1];
        this.modal('تنظیم کارت', field('عنوان کارت', input('title', this.cardSettingsTitleDraft)) + `<div class="mb-click-settings-summary"><strong>هنگام کلیک روی داده‌ها</strong><p class="mb-help">${e(summary)}${overrides ? ` · ${overrides} ستون با تنظیم جداگانه` : ''}</p>${button(icon('settings') + 'تنظیم رفتار کلیک', 'editCardClickBehavior')}</div>`, button('تنظیم نمایش', 'cardVisualization') + button('اعمال', 'saveCardSettings', 'primary'), false, true);
        this.root.querySelector('.mb-dialog').setAttribute('data-card-settings', '');
    },

    readCardSettingsForm() {
        if (!this.root.querySelector('.mb-dialog[data-card-settings]')) return;
        this.cardSettingsTitleDraft = String(this.form().get('title') || '').trim();
        this.cardDraft.settings.title = this.cardSettingsTitleDraft;
        this.cardDraft.click_behavior = copy(this.cardClickDraft);
    },

    async editCardClickBehavior() {
        const originatingDialog = this.root.querySelector('.mb-dialog');
        const modalGeneration = originatingDialog?.dataset.analyticsModalGeneration;
        this.cardSettingsTitleDraft = String(this.form().get('title') || '').trim();
        const widget = this.cardDraft;
        try {
            if (!this.results.has(widget.key)) await this.loadCard(widget);
        } catch (error) {
            if (!isCurrentFilamentModal(originatingDialog, modalGeneration)) return;
            throw error;
        }
        if (!isCurrentFilamentModal(originatingDialog, modalGeneration)) return;
        const columns = this.results.get(widget.key)?.columns || [];
        if (!columns.length) throw new Error('ابتدا نتیجهٔ کارت را دریافت کنید تا ستون‌های قابل کلیک مشخص شوند.');
        this.clickBehaviorEditor = { config: copy(this.cardClickDraft), scope: '*', columns, showTypeSelector: true };
        await this.renderClickBehaviorEditor();
    },

    behaviorForScope() {
        const state = this.clickBehaviorEditor;
        if (state.scope === '*') { const { columns, ...behavior } = state.config; return behavior; }
        if (state.config.columns?.[state.scope]) return state.config.columns[state.scope];
        const { columns, ...behavior } = state.config; return copy(behavior);
    },

    setBehaviorForScope(behavior) {
        const state = this.clickBehaviorEditor;
        if (state.scope === '*') state.config = { ...behavior, ...(state.config.columns ? { columns: state.config.columns } : {}) };
        else { state.config.columns ||= {}; state.config.columns[state.scope] = behavior; }
    },

    readClickBehaviorEditor() {
        if (!this.root.querySelector('.mb-dialog [data-click-behavior-editor]')) return;
        if (this.clickBehaviorEditor.showTypeSelector) return;
        const form = this.form(); const behavior = { ...this.behaviorForScope() };
        if (behavior.type === 'url') {
            behavior.url = String(form.get('url') || '').trim();
            behavior.link_text = String(form.get('link_text') || '').trim();
        }
        if (behavior.type === 'dashboard') behavior.dashboard_id = Number(form.get('dashboard_id')) || null;
        if (behavior.type === 'report') behavior.report_id = Number(form.get('report_id')) || null;
        if (['filter', 'dashboard', 'report'].includes(behavior.type)) {
            behavior.mappings = [];
            this.root.querySelectorAll('.mb-dialog [data-click-mapping-target]').forEach(control => {
                if (!control.value) return;
                const separator = control.value.indexOf(':');
                behavior.mappings.push({ target: control.dataset.clickMappingTarget, source: control.value.slice(0, separator), key: control.value.slice(separator + 1) });
            });
        }
        const state = this.clickBehaviorEditor;
        if (state.scope !== '*' && !Object.hasOwn(state.config.columns || {}, state.scope) && JSON.stringify(behavior) === JSON.stringify(this.behaviorForScope())) return;
        this.setBehaviorForScope(behavior);
    },

    async chooseClickBehavior(target) {
        this.readClickBehaviorEditor();
        const type = target.dataset.type;
        if (!types[type]) throw new Error('رفتار کلیک معتبر نیست.');
        if (this.behaviorForScope().type !== type) this.setBehaviorForScope({ type });
        this.clickBehaviorEditor.showTypeSelector = false;
        await this.renderClickBehaviorEditor();
    },

    async changeClickBehavior() {
        this.readClickBehaviorEditor(); this.clickBehaviorEditor.showTypeSelector = true;
        await this.renderClickBehaviorEditor();
    },

    clickMappingSources(target, allowParameters) {
        const state = this.clickBehaviorEditor;
        const compatible = source => !target.type || !source.type || (target.type === 'time_grain' ? source.type === 'date' : source.type === target.type);
        const fields = state.columns.filter(source => compatible(source));
        const parameters = allowParameters ? this.dashboard.filters.filter(source => compatible(source)) : [];
        return `<optgroup label="ستون‌های نتیجه">${options(fields.map(column => ({ key: 'column:' + column.key, label: column.label })), null)}</optgroup>` + (parameters.length ? `<optgroup label="فیلترهای این داشبورد">${options(parameters.map(parameter => ({ key: 'parameter:' + parameter.key, label: parameter.label })), null)}</optgroup>` : '');
    },

    async clickBehaviorTargets(behavior) {
        if (behavior.type === 'filter') return this.dashboard.filters;
        if (behavior.type === 'dashboard' && behavior.dashboard_id) {
            this.clickDestinationCache ||= new Map();
            if (!this.clickDestinationCache.has(behavior.dashboard_id)) this.clickDestinationCache.set(behavior.dashboard_id, await this.request(`dashboards/${behavior.dashboard_id}`));
            return this.clickDestinationCache.get(behavior.dashboard_id).filters;
        }
        if (behavior.type === 'report' && behavior.report_id) {
            const report = this.library.reports.find(row => row.id === behavior.report_id);
            if (!report) throw new Error('پرسش مقصد در دسترس نیست.');
            return this.dashboardFilterFields(report);
        }
        return [];
    },

    async renderClickBehaviorEditor() {
        const state = this.clickBehaviorEditor;
        const revision = this.clickBehaviorEditorRevision = (this.clickBehaviorEditorRevision || 0) + 1;
        const originatingDialog = this.root.querySelector('.mb-dialog');
        const modalGeneration = originatingDialog?.dataset.analyticsModalGeneration;
        const behavior = this.behaviorForScope();
        let targets;
        try { targets = await this.clickBehaviorTargets(behavior); }
        catch (error) {
            if (revision !== this.clickBehaviorEditorRevision || !isCurrentFilamentModal(originatingDialog, modalGeneration)) return;
            throw error;
        }
        if (revision !== this.clickBehaviorEditorRevision || !isCurrentFilamentModal(originatingDialog, modalGeneration)) return;
        const scopeItems = [{ key: '*', label: 'رفتار پیش‌فرض کارت' }, ...state.columns.map(column => ({ key: column.key, label: column.label }))];
        let settings = '';
        if (behavior.type === 'dashboard') settings += field('داشبورد مقصد', select(this.library.dashboards.map(board => ({ key: board.id, label: board.name })), behavior.dashboard_id, 'name="dashboard_id" data-click-destination', 'انتخاب داشبورد…'));
        if (behavior.type === 'report') settings += field('پرسش مقصد', select(this.library.reports.map(report => ({ key: report.id, label: report.name })), behavior.report_id, 'name="report_id" data-click-destination', 'انتخاب پرسش…'));
        if (['filter', 'dashboard', 'report'].includes(behavior.type)) {
            settings += `<div class="mb-click-mappings"><h3>${behavior.type === 'filter' ? 'کدام فیلترها تغییر کنند؟' : 'مقادیر را به مقصد منتقل کنید'}</h3>${targets.length ? targets.map(target => {
                const sourceOptions = this.clickMappingSources(target, behavior.type !== 'filter');
                return `<div class="mb-click-mapping">${field(target.label || target.key, `<select class="mb-input" name="mapping_source_${e(target.key)}" data-click-mapping-target="${e(target.key)}"><option value="">بدون اتصال</option>${sourceOptions}</select>`)}</div>`;
            }).join('') : `<p class="mb-help">${behavior.type === 'filter' ? 'برای این داشبورد ابتدا یک فیلتر اضافه کنید.' : behavior.type === 'dashboard' && behavior.dashboard_id ? 'داشبورد مقصد فیلتری ندارد.' : 'ابتدا مقصد را انتخاب کنید.'}</p>`}</div>`;
        }
        if (behavior.type === 'url') {
            const references = [...state.columns.map(column => ({ token: `{{column:${column.key}}}`, label: column.label })), ...this.dashboard.filters.map(parameter => ({ token: `{{parameter:${parameter.key}}}`, label: parameter.label }))];
            settings += field('آدرس مقصد', input('url', behavior.url || '', 'text', 'dir="ltr" placeholder="https://example.com/orders/{{column:id}}"')) + field('متن نمایشی لینک (اختیاری)', input('link_text', behavior.link_text || '', 'text', 'placeholder="مثلاً مشاهدهٔ سفارش {{column:id}}"')) + `<div class="mb-click-template-values"><h3>مقادیر قابل استفاده در لینک</h3>${references.map(reference => `<button type="button" class="mb-btn small" data-action="insertClickTemplateValue" data-token="${e(reference.token)}" title="${e(reference.token)}">${e(reference.label)} ${icon('plus')}</button>`).join('')}<p class="mb-help">مقدارهای آدرس هنگام کلیک رمزگذاری می‌شوند. {{value}} نیز مقدار سلول کلیک‌شده را می‌گیرد.</p></div>`;
        }
        const typePicker = state.showTypeSelector ? `<div class="mb-click-options">${Object.entries(types).map(([type, [image, label, help]]) => `<button type="button" class="mb-click-option ${behavior.type === type ? 'active' : ''}" data-action="chooseClickBehavior" data-type="${type}" aria-pressed="${behavior.type === type}">${icon(image)}<span><strong>${e(label)}</strong><small>${e(help)}</small></span>${behavior.type === type ? icon('check') : ''}</button>`).join('')}</div>` : `<div class="mb-click-selected">${button(icon(types[behavior.type][0]) + e(types[behavior.type][1]), 'changeClickBehavior', 'mb-click-selected-label')}${iconButton('close', 'انتخاب رفتار دیگر', 'changeClickBehavior')}</div>`;
        const body = `<div class="mb-click-behavior" data-click-behavior-editor>${field('رفتار کدام ستون؟', select(scopeItems, state.scope, 'name="click_scope" data-click-scope'))}${typePicker}<div class="mb-click-details">${state.showTypeSelector ? '' : settings}</div></div>`;
        this.modal('تنظیم رفتار کلیک', body, button('انصراف', 'cancelCardClickBehavior') + button('اعمال رفتار کلیک', 'saveCardClickBehavior', 'primary'), false, true);
        const dialog = this.root.querySelector('.mb-dialog');
        dialog.setAttribute('data-click-behavior-dialog', '');
        dialog.querySelectorAll('[data-click-mapping-target]').forEach(control => {
            const mapping = behavior.mappings?.find(row => row.target === control.dataset.clickMappingTarget);
            if (mapping) control.value = mapping.source + ':' + mapping.key;
        });
        dialog.querySelector('[data-click-scope]').addEventListener('change', async event => {
            try { this.readClickBehaviorEditor(); state.scope = event.target.value; state.showTypeSelector = state.scope === '*' || !Object.hasOwn(state.config.columns || {}, state.scope); await this.renderClickBehaviorEditor(); } catch (error) { this.toast(error.message, true); }
        });
        dialog.querySelectorAll('[data-click-destination]').forEach(control => control.addEventListener('change', async () => {
            try { this.readClickBehaviorEditor(); const changed = this.behaviorForScope(); changed.mappings = []; this.setBehaviorForScope(changed); await this.renderClickBehaviorEditor(); } catch (error) { this.toast(error.message, true); }
        }));
        dialog.querySelectorAll('[name=url], [name=link_text]').forEach(control => control.addEventListener('focus', () => { this.clickTemplateInput = control.name; }));
    },

    insertClickTemplateValue(target) {
        const control = this.root.querySelector(`.mb-dialog [name="${this.clickTemplateInput || 'url'}"]`);
        const start = control.selectionStart ?? control.value.length, end = control.selectionEnd ?? start;
        control.setRangeText(target.dataset.token, start, end, 'end'); control.focus();
    },

    validateClickBehavior(behavior) {
        if (!types[behavior.type]) throw new Error('رفتار کلیک معتبر نیست.');
        if (behavior.type === 'filter' && !behavior.mappings?.length) throw new Error('حداقل یک فیلتر مقصد را به ستون نتیجه متصل کنید.');
        if (behavior.type === 'dashboard' && !behavior.dashboard_id) throw new Error('داشبورد مقصد را انتخاب کنید.');
        if (behavior.type === 'report' && !behavior.report_id) throw new Error('پرسش مقصد را انتخاب کنید.');
        if (behavior.type === 'url') {
            if (!/^https?:\/\//i.test(behavior.url || '')) throw new Error('آدرس باید با http یا https شروع شود.');
            const columns = new Set(this.clickBehaviorEditor.columns.map(column => column.key));
            const parameters = new Set(this.dashboard.filters.map(parameter => parameter.key));
            for (const template of [behavior.url, behavior.link_text || '']) {
                for (const [token] of template.matchAll(/\{\{[^{}]+\}\}/g)) {
                    if (token === '{{value}}') continue;
                    const match = token.match(/^\{\{(column|parameter):([^{}]+)\}\}$/);
                    if (!match || !(match[1] === 'column' ? columns : parameters).has(match[2])) throw new Error('یک مقدار استفاده‌شده در لینک وجود ندارد؛ از فهرست مقادیر قابل استفاده انتخاب کنید.');
                }
            }
        }
    },

    saveCardClickBehavior() {
        this.readClickBehaviorEditor();
        const state = this.clickBehaviorEditor;
        const { columns, ...base } = state.config;
        this.validateClickBehavior(base);
        for (const behavior of Object.values(columns || {})) this.validateClickBehavior(behavior);
        this.cardClickDraft = copy(state.config);
        this.clickBehaviorEditorRevision++;
        this.renderCardSettingsDialog();
    },

    cancelCardClickBehavior() {
        this.clickBehaviorEditorRevision++;
        this.renderCardSettingsDialog();
    },

    removeDashboardFilter() {
        const key = this.filterDraft.key;
        this.dashboard.filters = this.dashboard.filters.filter(filter => filter.key !== key);
        this.dashboard.filters.forEach(filter => { if (filter.settings.parent_key === key) filter.settings.parent_key = null; });
        this.dashboard.widgets.forEach(widget => { widget.click_behavior = pruneClickFilterReferences(widget.click_behavior, key, this.dashboard.id); });
        delete this.filterValues[key]; delete this.appliedValues[key];
        this.clickDestinationCache?.delete(this.dashboard.id);
        this.markDirty(); this.render();
    },
};
