import { e, copy, icon, button, input, field, options, entries, displayNames } from './ui';
import { chartColorEntries, chartDefaultPalette, resolveSeriesColors, sanitizeSeriesColors } from './chart-style';
import { persistedPresentationSettings } from './drill-presentation';
const select = (items, value, attrs = '', placeholder = null) => `<select class="mb-input" ${attrs}>${options(items, value, placeholder)}</select>`;
const check = (name, label, value) => `<label class="mb-inline-check">${input(name, '', 'checkbox', value ? 'checked' : '')}${label}</label>`;
export const visualizationMethods = {
    visualizationDialog(settings, display, columns) { this.vizDraft = copy(settings); this.vizDisplay = display; this.vizColumns = columns; this.vizResult = this.vizTarget === 'report' ? this.previewResult : this.results.get(this.vizTarget); const rendered = this.vizTarget === 'report' ? this.root.querySelector('.mb-preview-body') : this.root.querySelector('[data-widget="' + CSS.escape(this.vizTarget) + '"] .mb-card-body'); if (rendered?._analyticsVisualization?.settings?._series_colors) this.vizDraft._series_colors = { ...rendered._analyticsVisualization.settings._series_colors }; this.vizTab = 'data'; this.visualizationPanel(); },
    visualizationPanel() {
        const s = this.vizDraft; const display = this.vizDisplay; const columns = this.vizColumns; const numeric = columns.filter(row => row.type === 'number'); const tab = this.vizTab;
        let body = '';
        if (tab === 'data') {
            body = field('نوع نمایش', select(entries(displayNames), display, 'name="display" data-viz-display'));
            if (display === 'table') body += '<strong>ستون‌های قابل نمایش</strong>' + columns.map(row => check('visible_columns', e(row.label), !s.visible_columns?.length || s.visible_columns.includes(row.key)).replace('value=""', `value="${e(row.key)}"`)).join('') + field('ردیف در هر صفحه', select([10, 25, 50, 100].map(key => ({ key, label: key })), s.page_size || 25, 'name="page_size"'));
            else { if (!['number', 'progress', 'gauge'].includes(display)) body += field(display === 'pivot' ? 'ردیف‌ها' : 'محور افقی / دسته‌ها', select(columns, s.x, 'name="x"', 'خودکار')); if (display === 'pivot') body += field('ستون‌ها', select(columns, s.split, 'name="split"', 'خودکار')); body += field('مقدار عددی', select(numeric, s.y, 'name="y"', 'خودکار')); }
        } else if (tab === 'display') {
            body = field('عنوان / توضیح عدد', input('caption', s.caption || '')) + field('رنگ اصلی', input('color', s.color && (s.color !== '#509ee3' || s.color_custom) ? s.color : chartDefaultPalette(display, this.root)[0], 'color', 'data-base-chart-color'));
            if (['progress', 'gauge'].includes(display)) body += field('هدف', input('target', s.target || 100, 'number', 'min="0.000001" step="any"'));
            if (['bar', 'line', 'area', 'pie', 'doughnut'].includes(display)) body += check('legend', 'نمایش راهنمای نمودار', s.legend !== false);
            if (['bar', 'area'].includes(display)) body += check('stacked', 'نمایش تجمعی', !!s.stacked);
            if (display === 'bar') body += check('horizontal', 'نمایش افقی', !!s.horizontal);
            if (['line', 'area'].includes(display)) body += check('points', 'نمایش نقاط', s.points !== false) + check('smooth', 'خطوط نرم', s.smooth !== false);
            if (display === 'bar') body += check('color_by_category', 'رنگ جداگانه برای دسته‌ها', s.color_by_category ?? !s.horizontal);
            if (display === 'gauge') body += field('شکل گیج', select([{ key: 'semi', label: 'نیم‌دایره با نشانگر' }, { key: 'ring', label: 'حلقه با نشانگر مقدار' }], s.gauge_style || 'semi', 'name="gauge_style"'));
            if (['pie', 'doughnut'].includes(display)) body += field('نمایش درصدها', select([{ key: 'off', label: 'مخفی' }, { key: 'legend', label: 'در راهنما' }, { key: 'inside', label: 'روی نمودار' }, { key: 'both', label: 'روی نمودار و در راهنما' }], s.percent_visibility || 'off', 'name="percent_visibility"'));
            if (display === 'doughnut') {
                body += check('show_total', 'نمایش مقدار در مرکز', s.show_total !== false) + field('مقدار مرکز', select([{ key: 'total', label: 'مجموع' }, { key: 'percentage', label: 'درصد دستهٔ انتخاب‌شده' }, { key: 'none', label: 'مخفی' }], s.center_mode || 'total', 'name="center_mode"')) + field('ضخامت حلقه (درصد شعاع)', input('ring_thickness', s.ring_thickness ?? 28, 'number', 'min="10" max="45" step="1"'));
                if (this.vizResult) body += field('دستهٔ مرکز درصد', select(chartColorEntries(this.vizResult, display, s), s.center_key, 'name="center_key"', 'بزرگ‌ترین دسته'));
            }
            if (this.vizResult && ['bar', 'line', 'area', 'pie', 'doughnut', 'scatter', 'funnel'].includes(display)) {
                const runtime = this.runtimeVisualizationSettings(this.vizResult, this.vizTarget === 'report' ? this.report.query_definition : this.dashboardReport(this.dashboard.widgets.find(row => row.key === this.vizTarget).report_id).query_definition, s);
                const colorEntries = chartColorEntries(this.vizResult, display, runtime); const colors = resolveSeriesColors(this.vizResult, display, runtime, this.root);
                if (colorEntries.length) body += '<section class="mb-series-color-settings"><h3>رنگ دسته‌ها و سری‌ها</h3><p class="mb-help">رنگ به خود مقدار متصل می‌شود و با فیلتر یا مرتب‌سازی جابه‌جا نمی‌شود.</p>' + colorEntries.slice(0, 100).map(entry => '<label><span>' + e(entry.label) + '</span><input type="color" aria-label="رنگ ' + e(entry.label) + '" data-series-color="' + e(entry.key) + '" value="' + e(colors[entry.key]) + '"></label>').join('') + (colorEntries.length > 100 ? '<p class="mb-help">۱۰۰ دستهٔ اول نمایش داده می‌شوند؛ رنگ سایر دسته‌ها با پالت تعیین می‌شود.</p>' : '') + button('بازنشانی رنگ دسته‌ها', 'resetVisualizationColors', 'small') + '</section>';
            }
        } else if (tab === 'axes') body = check('show_x', 'نمایش محور افقی', s.show_x !== false) + field('عنوان محور افقی', input('x_label', s.x_label || '')) + check('show_y', 'نمایش محور عمودی', s.show_y !== false) + field('عنوان محور عمودی', input('y_label', s.y_label || '')) + `<div class="mb-form-grid">${field('کمینهٔ محور عمودی', input('y_min', s.y_min ?? '', 'number', 'step="any" placeholder="خودکار"'))}${field('بیشینهٔ محور عمودی', input('y_max', s.y_max ?? '', 'number', 'step="any" placeholder="خودکار"'))}</div>`;
        else body = field('تعداد رقم اعشار', input('decimals', s.decimals ?? 0, 'number', 'min="0" max="6"')) + field('پیشوند', input('prefix', s.prefix || '')) + field('پسوند', input('suffix', s.suffix || ''));
        const tabs = { data: 'داده‌ها', display: 'نمایش', ...(['bar', 'line', 'area', 'scatter'].includes(display) ? { axes: 'محورها' } : {}), format: 'قالب‌بندی' };
        this.modal('تنظیمات نمایش', `<nav class="mb-viz-settings-tabs">${Object.entries(tabs).map(([key, label]) => `<button class="${tab === key ? 'active' : ''}" data-action="visualizationTab" data-tab="${key}">${label}</button>`).join('')}</nav>${body}`, button('انصراف', 'closeModal') + button('اعمال', 'saveVisualization', 'primary'), false, true);
    },
    readVisualizationForm() {
        const form = this.form(); const root = this.root.querySelector('.mb-dialog form');
        for (const node of root.querySelectorAll('[name]')) { if (node.name === 'display') { this.vizDisplay = node.value; continue; } if (node.name === 'visible_columns' || node.name === 'color' && node.dataset.colorChanged !== 'true') continue; this.vizDraft[node.name] = node.type === 'checkbox' ? node.checked : node.type === 'number' ? node.value === '' ? '' : Number(node.value) : node.value; }
        if (root.querySelector('[name=visible_columns]')) this.vizDraft.visible_columns = form.getAll('visible_columns');
        if (form.has('page_size')) this.vizDraft.page_size = Number(form.get('page_size'));
        const colors = { ...sanitizeSeriesColors(this.vizDraft.series_colors) };
        root.querySelectorAll('[data-series-color]').forEach(node => { if (node.dataset.colorChanged === 'true') colors[node.dataset.seriesColor] = node.value; });
        if (Object.keys(colors).length) this.vizDraft.series_colors = colors;
        const baseColor = root.querySelector('[data-base-chart-color]'); if (baseColor?.dataset.colorChanged === 'true') { this.vizDraft.color_custom = true; delete this.vizDraft._series_colors; this.visualizationColors.clear(); }
    },
    resetVisualizationColors() { this.readVisualizationForm(); this.vizDraft.series_colors = {}; delete this.vizDraft._series_colors; this.visualizationColors.clear(); this.visualizationPanel(); },
    visualizationTab(target) { this.readVisualizationForm(); this.vizTab = target.dataset.tab; this.visualizationPanel(); },
    visualizationDisplayChanged() { const previous = this.vizDisplay; this.readVisualizationForm(); if (previous !== this.vizDisplay) { delete this.vizDraft._series_colors; this.visualizationColors.clear(); } this.visualizationPanel(); },
    saveVisualization() { this.readVisualizationForm(); const s = persistedPresentationSettings(this.vizDraft); if (s.decimals != null && (!Number.isInteger(s.decimals) || s.decimals < 0 || s.decimals > 6)) throw new Error('اعشار باید بین ۰ و ۶ باشد.'); if (s.target != null && Number(s.target) <= 0) throw new Error('هدف باید بزرگ‌تر از صفر باشد.'); if (s.ring_thickness != null && (!Number.isInteger(s.ring_thickness) || s.ring_thickness < 10 || s.ring_thickness > 45)) throw new Error('ضخامت حلقه باید عدد صحیح بین ۱۰ و ۴۵ باشد.'); if (s.y_min !== '' && s.y_max !== '' && s.y_min != null && s.y_max != null && Number(s.y_min) >= Number(s.y_max)) throw new Error('بیشینهٔ محور باید بزرگ‌تر از کمینه باشد.'); if (this.vizDisplay === 'table' && s.visible_columns && !s.visible_columns.length) throw new Error('حداقل یک ستون انتخاب کنید.'); if (this.vizTarget === 'report') { this.report.display = this.vizDisplay; this.report.visualization_settings = s; } else { const widget = this.dashboard.widgets.find(row => row.key === this.vizTarget); widget.settings = { ...widget.settings, ...s, display: this.vizDisplay }; } this.markDirty(); this.closeModal(); this.render(); },
};
