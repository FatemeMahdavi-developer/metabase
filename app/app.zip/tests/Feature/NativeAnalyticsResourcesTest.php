<?php

namespace Tests\Feature;

use App\Domain\Analytics\Drivers\ConnectionManager;
use App\Domain\Analytics\Filament\PanelActions;
use App\Domain\Analytics\ReportRunner;
use App\Filament\Pages\AnalyticsDashboardEditor;
use App\Filament\Pages\AnalyticsReportEditor;
use App\Filament\Resources\AnalyticsConnectionResource;
use App\Filament\Resources\AnalyticsConnectionResource\Pages\ListAnalyticsConnections;
use App\Filament\Resources\AnalyticsDashboardResource;
use App\Filament\Resources\AnalyticsDashboardResource\Pages\ListAnalyticsDashboards;
use App\Filament\Resources\AnalyticsReportResource;
use App\Filament\Resources\AnalyticsReportResource\Pages\ListAnalyticsReports;
use App\Models\AnalyticsConnection;
use App\Models\AnalyticsDashboard;
use App\Models\AnalyticsReport;
use App\Models\User;
use Filament\Facades\Filament;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Livewire\Livewire;
use PDO;
use Symfony\Component\HttpKernel\Exception\HttpException;
use Tests\TestCase;

class NativeAnalyticsResourcesTest extends TestCase
{
    use RefreshDatabase;

    private User $owner;

    private string $sourcePath;

    protected function setUp(): void
    {
        parent::setUp();
        // The application's base User uses Filament's local-environment access rule.
        config(['app.env' => 'local']);
        $this->owner = User::factory()->create();
        $this->actingAs($this->owner);
        Filament::setCurrentPanel(Filament::getPanel('admin'));
        Filament::bootCurrentPanel();
        $this->sourcePath = storage_path('framework/native-panel-'.bin2hex(random_bytes(6)).'.sqlite');
        $source = new PDO('sqlite:'.$this->sourcePath);
        $source->exec('CREATE TABLE events (id INTEGER PRIMARY KEY, amount INTEGER); INSERT INTO events VALUES (1,10),(2,20)');
    }

    protected function tearDown(): void
    {
        parent::tearDown();
        if (isset($this->sourcePath) && is_file($this->sourcePath)) {
            unlink($this->sourcePath);
        }
    }

    private function connection(?User $owner = null, string $driver = 'sqlite'): AnalyticsConnection
    {
        return AnalyticsConnection::create([
            'owner_id' => ($owner ?? $this->owner)->id, 'name' => 'Native source '.$driver, 'driver' => $driver,
            'configuration' => $driver === 'sqlite' ? ['path' => $this->sourcePath] : ['host' => 'localhost', 'port' => 8123, 'database' => 'events', 'username' => 'default', 'password' => 'private-panel-test-secret'],
        ]);
    }

    private function normalizedJsonMaps(array $value): array
    {
        $value = array_map(fn ($item) => is_array($item) ? $this->normalizedJsonMaps($item) : $item, $value);
        if (! array_is_list($value)) {
            ksort($value);
        }

        return $value;
    }

    public function test_native_resource_lists_use_own_routes_and_exclude_other_users_records(): void
    {
        $other = User::factory()->create();
        $own = $this->connection();
        $foreign = $this->connection($other);
        Livewire::test(ListAnalyticsConnections::class)->assertSuccessful()->assertCanSeeTableRecords([$own])->assertCanNotSeeTableRecords([$foreign]);
        $this->assertSame('/admin/analytics/databases', parse_url(AnalyticsConnectionResource::getUrl(), PHP_URL_PATH));
        $this->assertSame('/admin/analytics/dashboards', parse_url(AnalyticsDashboardResource::getUrl(), PHP_URL_PATH));
        $this->assertSame('/admin/analytics/reports', parse_url(AnalyticsReportResource::getUrl(), PHP_URL_PATH));
        foreach ([AnalyticsConnectionResource::getUrl(), AnalyticsDashboardResource::getUrl(), AnalyticsReportResource::getUrl()] as $url) {
            $this->get($url)->assertOk()->assertSee('fi-sidebar', false)->assertDontSee('id="analytics-studio"', false);
        }
    }

    public function test_native_dashboard_create_initializes_tabs_and_redirects_to_its_editor(): void
    {
        $component = Livewire::test(ListAnalyticsDashboards::class)
            ->callAction('create', data: ['name' => 'Native dashboard', 'description' => 'Created through Filament'])
            ->assertHasNoActionErrors();
        $dashboard = AnalyticsDashboard::where('name', 'Native dashboard')->firstOrFail();
        $this->assertSame($this->owner->id, $dashboard->owner_id);
        $this->assertSame(['auto_apply' => true, 'width' => 'wide', 'refresh_interval' => 0], $dashboard->settings);
        $this->assertDatabaseHas('analytics_dashboard_tabs', ['dashboard_id' => $dashboard->id, 'key' => 'main']);
        $component->assertRedirect(AnalyticsDashboardEditor::getUrl(['record' => $dashboard->id]));
    }

    public function test_native_collection_create_and_filter_are_owner_scoped(): void
    {
        Livewire::test(ListAnalyticsDashboards::class)->callAction('createFolder', data: ['name' => 'Native folder'])->assertHasNoActionErrors();
        $folder = DB::table('analytics_folders')->where('name', 'Native folder')->first();
        $this->assertSame($this->owner->id, $folder->owner_id);
        $own = app(PanelActions::class)->createDashboard(['name' => 'In folder', 'folder_id' => $folder->id]);
        $otherFolder = app(PanelActions::class)->createDashboard(['name' => 'Without folder']);
        Livewire::test(ListAnalyticsDashboards::class)->filterTable('folder_id', $folder->id)->assertCanSeeTableRecords([$own])->assertCanNotSeeTableRecords([$otherFolder]);
    }

    public function test_shared_dashboard_is_listed_but_viewer_cannot_delete_it(): void
    {
        $dashboard = app(PanelActions::class)->createDashboard(['name' => 'Shared dashboard']);
        $viewer = User::factory()->create();
        DB::table('analytics_dashboard_members')->insert(['dashboard_id' => $dashboard->id, 'user_id' => $viewer->id, 'role' => 'viewer']);
        $this->actingAs($viewer);
        Livewire::test(ListAnalyticsDashboards::class)->assertCanSeeTableRecords([$dashboard])->assertTableActionHidden('delete', $dashboard)->assertTableActionHidden('copy', $dashboard);
        $this->get(AnalyticsDashboardEditor::getUrl(['record' => $dashboard->id]))->assertOk();
    }

    public function test_native_database_modal_creates_and_syncs_sqlite_without_external_services(): void
    {
        Livewire::test(ListAnalyticsConnections::class)->callAction('create', data: [
            'name' => 'Native SQLite', 'driver' => 'sqlite', 'configuration' => ['path' => $this->sourcePath], 'test_first' => true,
        ])->assertHasNoActionErrors();
        $record = AnalyticsConnection::where('name', 'Native SQLite')->firstOrFail();
        $this->assertSame($this->owner->id, $record->owner_id);
        $this->assertNotNull($record->synced_at);
        $this->assertContains('events', array_column($record->catalog, 'key'));
        Livewire::test(ListAnalyticsConnections::class)->callTableAction('sync', $record)->assertHasNoTableActionErrors();
    }

    public function test_edit_connection_keeps_password_private_and_preserves_it_when_empty(): void
    {
        $record = $this->connection(driver: 'clickhouse');
        $component = Livewire::test(ListAnalyticsConnections::class)->mountTableAction('edit', $record)
            ->assertTableActionDataSet(['name' => $record->name, 'configuration.host' => 'localhost']);
        $this->assertStringNotContainsString('private-panel-test-secret', json_encode($component->get('mountedTableActionsData')));
        $component->setTableActionData(['name' => 'Renamed native source', 'configuration.password' => '', 'configuration.port' => '8443'])->callMountedTableAction()->assertHasNoTableActionErrors();
        $this->assertSame('private-panel-test-secret', $record->refresh()->configuration['password']);
        $this->assertSame('Renamed native source', $record->name);
        $this->assertSame(8443, $record->configuration['port']);
    }

    public function test_connection_failure_is_reported_without_saving_invalid_source(): void
    {
        Livewire::test(ListAnalyticsConnections::class)->callAction('create', data: [
            'name' => 'Invalid SQLite', 'driver' => 'sqlite', 'configuration' => ['path' => $this->sourcePath.'.missing'], 'test_first' => true,
        ])->assertHasActionErrors();
        $this->assertDatabaseMissing('analytics_connections', ['name' => 'Invalid SQLite']);
    }

    public function test_native_report_metadata_retains_query_and_detects_a_stale_version(): void
    {
        $connection = $this->connection();
        app(ConnectionManager::class)->sync($connection);
        $definition = ['connection_id' => $connection->id, 'source' => 'events', 'mode' => 'rows', 'metrics' => [], 'dimensions' => [], 'filters' => [], 'sort' => [], 'limit' => 20];
        $report = AnalyticsReport::create(['owner_id' => $this->owner->id, 'name' => 'Native report', 'query_definition' => $definition, 'display' => 'table', 'visualization_settings' => ['decimals' => 2]]);
        $component = Livewire::test(ListAnalyticsReports::class)->callTableAction('edit', $report, data: ['name' => 'Native report renamed', 'description' => 'Metadata only', 'version' => 1])->assertHasNoTableActionErrors();
        $this->assertSame('Native report renamed', $report->refresh()->name);
        $this->assertSame(2, $report->version);
        $this->assertSame('events', $report->query_definition['source']);
        $this->assertSame(['decimals' => 2], $report->visualization_settings);
        $component->callTableAction('edit', $report, data: ['name' => 'Stale edit', 'version' => 1])->assertHasTableActionErrors();
        $this->assertSame('Native report renamed', $report->refresh()->name);
    }

    public function test_panel_adapter_rejects_another_users_connection_record(): void
    {
        $record = $this->connection(User::factory()->create());
        $this->expectException(HttpException::class);
        app(PanelActions::class)->saveConnection(['name' => 'Attempted takeover', 'driver' => 'sqlite', 'configuration' => ['path' => $this->sourcePath]], $record);
    }

    public function test_native_report_display_filter_finds_doughnut_and_pivot_reports_with_translated_labels(): void
    {
        $connection = $this->connection();
        $definition = [
            'connection_id' => $connection->id, 'source' => 'events', 'mode' => 'aggregate',
            'metrics' => [['key' => 'total', 'function' => 'sum', 'field' => 'amount', 'label' => 'Total']],
            'dimensions' => [['field' => 'id', 'grain' => null]], 'filters' => [], 'sort' => [], 'limit' => 20,
        ];
        $reports = collect(['doughnut', 'pivot', 'table'])->mapWithKeys(fn (string $display) => [
            $display => AnalyticsReport::create(['owner_id' => $this->owner->id, 'name' => 'Native '.$display, 'query_definition' => $definition, 'display' => $display, 'visualization_settings' => []]),
        ]);

        Livewire::test(ListAnalyticsReports::class)
            ->assertCanSeeTableRecords($reports->values())
            ->filterTable('display', 'doughnut')
            ->assertCanSeeTableRecords([$reports['doughnut']])
            ->assertCanNotSeeTableRecords([$reports['pivot'], $reports['table']])
            ->assertTableColumnFormattedStateSet('display', 'دونات', $reports['doughnut'])
            ->filterTable('display', 'pivot')
            ->assertCanSeeTableRecords([$reports['pivot']])
            ->assertCanNotSeeTableRecords([$reports['doughnut'], $reports['table']])
            ->assertTableColumnFormattedStateSet('display', 'جدول محوری', $reports['pivot']);
    }

    public function test_native_report_copy_preserves_query_and_settings_but_has_its_own_identity_and_permissions(): void
    {
        $connection = $this->connection();
        app(ConnectionManager::class)->sync($connection);
        $definition = app(ReportRunner::class)->validate([
            'connection_id' => $connection->id, 'source' => 'events', 'mode' => 'rows',
            'metrics' => [], 'dimensions' => [], 'filters' => [], 'sort' => [['key' => 'amount', 'direction' => 'desc']], 'limit' => 20,
        ], $this->owner->id);
        $original = AnalyticsReport::create([
            'owner_id' => $this->owner->id, 'name' => 'Original report', 'description' => 'Original description', 'version' => 8,
            'query_definition' => $definition, 'display' => 'table', 'visualization_settings' => ['decimals' => 2, 'color' => '#314CFF'],
        ]);
        $component = Livewire::test(ListAnalyticsReports::class)
            ->mountTableAction('copy', $original)
            ->assertTableActionDataSet(['name' => 'Original report — کپی', 'description' => 'Original description'])
            ->setTableActionData(['name' => 'Independent copy', 'description' => 'Copy description'])
            ->callMountedTableAction()->assertHasNoTableActionErrors();
        $copy = AnalyticsReport::where('name', 'Independent copy')->firstOrFail();
        $this->assertNotSame($original->id, $copy->id);
        $this->assertSame($this->owner->id, $copy->owner_id);
        $this->assertSame(1, $copy->version);
        // JSON object key order is incidental; query list order and scalar types are preserved.
        $this->assertSame($this->normalizedJsonMaps($definition), $this->normalizedJsonMaps($copy->query_definition));
        $this->assertSame($original->visualization_settings, $copy->visualization_settings);
        $this->assertSame($original->display, $copy->display);
        $this->assertSame('Copy description', $copy->description);
        $this->assertSame('Original report', $original->refresh()->name);
        $this->assertSame('Original description', $original->description);
        $this->assertSame(8, $original->version);
        $component->assertRedirect(AnalyticsReportEditor::getUrl(['record' => $copy->id]));

        $this->actingAs(User::factory()->create());
        Livewire::test(ListAnalyticsReports::class)->assertCanNotSeeTableRecords([$original, $copy])->assertTableActionHidden('copy', $original);
        try {
            app(PanelActions::class)->copyReport($original, ['name' => 'Forbidden copy']);
            $this->fail('Another user must not be able to copy this report.');
        } catch (HttpException $exception) {
            $this->assertSame(403, $exception->getStatusCode());
        }
        $this->assertDatabaseMissing('analytics_reports', ['name' => 'Forbidden copy']);
    }
}
