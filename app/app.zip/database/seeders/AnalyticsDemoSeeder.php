<?php

namespace Database\Seeders;

use App\Domain\Analytics\DashboardStore;
use App\Domain\Analytics\Drivers\ConnectionManager;
use App\Models\AnalyticsConnection;
use App\Models\AnalyticsDashboard;
use App\Models\AnalyticsReport;
use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use PDO;

class AnalyticsDemoSeeder extends Seeder
{
    public function run(): void
    {
        $user = User::orderBy('id')->firstOrFail();
        $path = database_path('analytics-sample-'.$user->id.'.sqlite');
        $pdo = new PDO('sqlite:'.$path, null, null, [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]);
        $pdo->exec('PRAGMA foreign_keys=ON');
        $pdo->exec('CREATE TABLE IF NOT EXISTS customers (id INTEGER PRIMARY KEY, name TEXT NOT NULL, city TEXT NOT NULL, joined_at DATE NOT NULL);
            CREATE TABLE IF NOT EXISTS categories (id INTEGER PRIMARY KEY, name TEXT NOT NULL);
            CREATE TABLE IF NOT EXISTS products (id INTEGER PRIMARY KEY, category_id INTEGER REFERENCES categories(id), name TEXT NOT NULL, price DECIMAL NOT NULL);
            CREATE TABLE IF NOT EXISTS orders (id INTEGER PRIMARY KEY, customer_id INTEGER REFERENCES customers(id), ordered_at DATE NOT NULL, status TEXT NOT NULL, total DECIMAL NOT NULL);
            CREATE TABLE IF NOT EXISTS order_items (id INTEGER PRIMARY KEY, order_id INTEGER REFERENCES orders(id), product_id INTEGER REFERENCES products(id), quantity INTEGER NOT NULL, amount DECIMAL NOT NULL);
            CREATE TABLE IF NOT EXISTS payments (id INTEGER PRIMARY KEY, order_id INTEGER REFERENCES orders(id), paid_at DATE NOT NULL, method TEXT NOT NULL, amount DECIMAL NOT NULL);
            CREATE INDEX IF NOT EXISTS orders_date ON orders(ordered_at);
            CREATE VIEW IF NOT EXISTS sales_overview AS SELECT o.id, o.ordered_at, o.status, o.total, c.name AS customer, c.city FROM orders o JOIN customers c ON c.id=o.customer_id;');
        if (! $pdo->query('SELECT COUNT(*) FROM customers')->fetchColumn()) {
            $pdo->beginTransaction();
            $cities = ['تهران', 'شیراز', 'اصفهان', 'تبریز', 'مشهد'];
            $insert = $pdo->prepare('INSERT INTO customers VALUES (?, ?, ?, ?)');
            for ($id = 1; $id <= 80; $id++) {
                $insert->execute([$id, 'مشتری نمونه '.$id, $cities[($id - 1) % 5], '2026-01-'.str_pad((string) (($id % 28) + 1), 2, '0', STR_PAD_LEFT)]);
            }
            $insert = $pdo->prepare('INSERT INTO categories VALUES (?, ?)');
            foreach (['دیجیتال', 'خانه', 'پوشاک', 'کتاب'] as $index => $name) {
                $insert->execute([$index + 1, $name]);
            }
            $insert = $pdo->prepare('INSERT INTO products VALUES (?, ?, ?, ?)');
            for ($id = 1; $id <= 20; $id++) {
                $insert->execute([$id, (($id - 1) % 4) + 1, 'کالای نمونه '.$id, 150000 + $id * 25000]);
            }
            $order = $pdo->prepare('INSERT INTO orders VALUES (?, ?, ?, ?, ?)');
            $item = $pdo->prepare('INSERT INTO order_items VALUES (?, ?, ?, ?, ?)');
            $payment = $pdo->prepare('INSERT INTO payments VALUES (?, ?, ?, ?, ?)');
            for ($id = 1; $id <= 600; $id++) {
                $date = (new \DateTimeImmutable('2026-01-01'))->modify('+'.(($id * 13) % 283).' days')->format('Y-m-d');
                $product = ($id % 20) + 1;
                $quantity = ($id % 4) + 1;
                $amount = (150000 + $product * 25000) * $quantity;
                $status = $id % 9 === 0 ? 'لغوشده' : ($id % 7 === 0 ? 'در انتظار' : 'تکمیل‌شده');
                $order->execute([$id, ($id % 80) + 1, $date, $status, $amount]);
                $item->execute([$id, $id, $product, $quantity, $amount]);
                if ($status === 'تکمیل‌شده') {
                    $payment->execute([$id, $id, $date, $id % 3 ? 'درگاه آنلاین' : 'کارت بانکی', $amount]);
                }
            }
            $pdo->commit();
        }
        $connection = AnalyticsConnection::firstOrCreate(['owner_id' => $user->id, 'name' => 'فروشگاه نمونه • SQLite'], ['driver' => 'sqlite', 'configuration' => ['path' => $path]]);
        if (! $connection->metadata) {
            $tableNames = ['customers' => 'مشتریان', 'categories' => 'دسته‌بندی‌ها', 'products' => 'کالاها', 'orders' => 'سفارش‌ها', 'order_items' => 'اقلام سفارش', 'payments' => 'پرداخت‌ها', 'sales_overview' => 'نمای فروش'];
            $fieldNames = ['id' => 'شناسه', 'name' => 'نام', 'city' => 'شهر', 'joined_at' => 'تاریخ عضویت', 'category_id' => 'دسته‌بندی', 'price' => 'قیمت', 'customer_id' => 'مشتری', 'ordered_at' => 'تاریخ سفارش', 'status' => 'وضعیت', 'total' => 'مبلغ کل', 'order_id' => 'سفارش', 'product_id' => 'کالا', 'quantity' => 'تعداد', 'amount' => 'مبلغ', 'paid_at' => 'تاریخ پرداخت', 'method' => 'روش پرداخت', 'customer' => 'نام مشتری'];
            $metadata = [];
            foreach ($tableNames as $key => $label) {
                $metadata[$key] = ['label' => $label, 'fields' => array_map(fn ($name) => ['label' => $name], $fieldNames)];
            }
            $connection->update(['metadata' => $metadata]);
        }
        app(ConnectionManager::class)->sync($connection);
        $folderId = DB::table('analytics_folders')->where('owner_id', $user->id)->where('name', 'نمونه‌ها')->value('id');
        $folderId ??= DB::table('analytics_folders')->insertGetId(['owner_id' => $user->id, 'name' => 'نمونه‌ها', 'created_at' => now(), 'updated_at' => now()]);
        $base = ['connection_id' => $connection->id, 'source' => 'sales_overview', 'mode' => 'aggregate', 'metrics' => [], 'dimensions' => [], 'filters' => [], 'sort' => [], 'joins' => [], 'limit' => 100];
        $definitions = [
            ['کل فروش', 'number', [['key' => 'revenue', 'function' => 'sum', 'field' => 'total']], []],
            ['تعداد سفارش‌ها', 'number', [['key' => 'orders', 'function' => 'count', 'field' => null]], []],
            ['روند فروش ماهانه', 'area', [['key' => 'revenue', 'function' => 'sum', 'field' => 'total']], [['field' => 'ordered_at', 'grain' => 'month']]],
            ['فروش به تفکیک شهر', 'bar', [['key' => 'revenue', 'function' => 'sum', 'field' => 'total']], [['field' => 'city', 'grain' => null]]],
            ['وضعیت سفارش‌ها', 'doughnut', [['key' => 'orders', 'function' => 'count', 'field' => null]], [['field' => 'status', 'grain' => null]]],
        ];
        $reports = [];
        foreach ($definitions as [$name, $display, $metrics, $dimensions]) {
            $reports[] = AnalyticsReport::firstOrCreate(['owner_id' => $user->id, 'name' => $name], [
                'folder_id' => $folderId, 'description' => 'گزارش ساخته‌شده از دیتابیس نمونه برای آزمایش.',
                'query_definition' => [...$base, 'metrics' => $metrics, 'dimensions' => $dimensions],
                'display' => $display, 'visualization_settings' => ['color' => '#509ee3', 'legend' => true, 'decimals' => 0],
            ]);
        }
        $dashboard = AnalyticsDashboard::firstOrCreate(['owner_id' => $user->id, 'name' => 'نمای کلی فروشگاه'], ['folder_id' => $folderId, 'version' => 0, 'settings' => []]);
        if ($dashboard->version === 0) {
            $positions = [[0, 0, 6, 4], [6, 0, 6, 4], [12, 0, 12, 8], [0, 4, 12, 8], [12, 8, 12, 7]];
            $widgets = [];
            foreach ($reports as $index => $report) {
                [$x, $y, $w, $h] = $positions[$index];
                $widgets[] = ['key' => 'sample-'.$index, 'type' => 'report', 'report_id' => $report->id, 'tab_key' => 'overview', 'x' => $x, 'y' => $y, 'w' => $w, 'h' => $h, 'settings' => [], 'click_behavior' => ['type' => 'details']];
            }
            $widgets[] = ['key' => 'sample-text', 'type' => 'text', 'report_id' => null, 'tab_key' => 'overview', 'x' => 0, 'y' => 12, 'w' => 12, 'h' => 4, 'content' => "### فضای تحلیل شما آماده است\nاین داشبورد از **۶۰۰ سفارش ساختگی** در یک فایل SQLite مستقل ساخته شده است. با «ویرایش داشبورد» کارت‌ها، اندازه‌ها و فیلترها را تغییر دهید.", 'settings' => [], 'click_behavior' => []];
            $bindings = array_map(fn ($widget) => ['widget_key' => $widget['key'], 'target' => 'ordered_at', 'operator' => 'between'], array_slice($widgets, 0, 5));
            app(DashboardStore::class)->save($dashboard, [
                'name' => $dashboard->name, 'description' => 'فروش، مشتریان و سفارش‌ها در یک نگاه • دادهٔ نمونه', 'folder_id' => $folderId, 'version' => 0,
                'settings' => ['auto_apply' => true, 'refresh_interval' => 0, 'width' => 'wide'], 'tabs' => [['key' => 'overview', 'name' => 'نمای کلی']],
                'widgets' => $widgets, 'filters' => [['key' => 'period', 'label' => 'بازهٔ زمانی', 'type' => 'date', 'required' => false, 'default_value' => null, 'settings' => ['operator' => 'between'], 'bindings' => $bindings]],
            ], $user->id);
        }
        $this->command?->info('SQLite sample ready: '.$path);
    }
}
