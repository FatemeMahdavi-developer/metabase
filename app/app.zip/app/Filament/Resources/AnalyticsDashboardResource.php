<?php

namespace App\Filament\Resources;

use App\Domain\Analytics\Filament\PanelActions;
use App\Filament\Pages\AnalyticsDashboardEditor;
use App\Filament\Resources\AnalyticsDashboardResource\Pages;
use App\Filament\Resources\Concerns\AnalyticsResourceHelpers;
use App\Models\AnalyticsDashboard;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Form;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class AnalyticsDashboardResource extends Resource
{
    use AnalyticsResourceHelpers;

    protected static ?string $model = AnalyticsDashboard::class;

    protected static ?string $slug = 'analytics/dashboards';

    protected static ?string $navigationIcon = 'heroicon-o-squares-2x2';

    protected static ?string $navigationGroup = 'داشبوردساز';

    protected static ?string $navigationLabel = 'داشبوردها';

    protected static ?string $modelLabel = 'داشبورد';

    protected static ?string $pluralModelLabel = 'داشبوردها';

    protected static ?string $recordTitleAttribute = 'name';

    protected static ?int $navigationSort = 10;

    protected static string $editorRoute = 'analytics.dashboard-editor';

    public static function getEloquentQuery(): Builder
    {
        $owner = static::ownerId();

        return parent::getEloquentQuery()->where(fn (Builder $query) => $query->where('owner_id', $owner)
            ->orWhereIn('id', DB::table('analytics_dashboard_members')->where('user_id', $owner)->select('dashboard_id')));
    }

    public static function canDelete(Model $record): bool
    {
        return $record->owner_id === static::ownerId();
    }

    public static function form(Form $form): Form
    {
        return $form->schema(static::metadataSchema());
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('name')->label('نام داشبورد')->searchable()->sortable()->icon('heroicon-o-squares-2x2')->description(fn (AnalyticsDashboard $record) => $record->description)->wrap(),
                TextColumn::make('folder_id')->label('مجموعه')->formatStateUsing(fn ($state) => DB::table('analytics_folders')->where('id', $state)->value('name') ?? 'بدون مجموعه')->placeholder('بدون مجموعه')->toggleable(),
                TextColumn::make('access')->label('دسترسی')->getStateUsing(fn (AnalyticsDashboard $record) => $record->owner_id === static::ownerId() ? 'مالک' : ($record->canEdit(static::ownerId()) ? 'ویرایشگر' : 'مشاهده‌گر'))->badge(),
                TextColumn::make('updated_at')->label('آخرین تغییر')->since()->sortable(),
            ])
            ->filters([static::folderFilter()])
            ->recordUrl(fn (AnalyticsDashboard $record) => AnalyticsDashboardEditor::getUrl(['record' => $record->id]))
            ->actions([
                Tables\Actions\Action::make('open')->label('باز کردن')->icon('heroicon-o-arrow-top-right-on-square')->url(fn (AnalyticsDashboard $record) => AnalyticsDashboardEditor::getUrl(['record' => $record->id])),
                Tables\Actions\Action::make('copy')->label('تکثیر')->icon('heroicon-o-document-duplicate')->visible(fn (AnalyticsDashboard $record) => $record->owner_id === static::ownerId())
                    ->form([Toggle::make('copy_reports')->label('گزارش‌های داخل داشبورد نیز کپی شوند')->default(false)])
                    ->action(function (AnalyticsDashboard $record, array $data, $livewire): void {
                        $copy = app(PanelActions::class)->copyDashboard($record, $data['copy_reports']);
                        $livewire->redirect(AnalyticsDashboardEditor::getUrl(['record' => $copy->id]));
                    }),
                Tables\Actions\DeleteAction::make()->label('حذف')->using(fn (AnalyticsDashboard $record) => app(PanelActions::class)->withoutForm(fn () => app(PanelActions::class)->deleteDashboard($record))),
            ])
            ->defaultSort('updated_at', 'desc')
            ->emptyStateHeading('هنوز داشبوردی ندارید')->emptyStateDescription('یک داشبورد بسازید و گزارش‌ها را به آن اضافه کنید.');
    }

    public static function getPages(): array
    {
        return ['index' => Pages\ListAnalyticsDashboards::route('/')];
    }
}
