<?php

namespace App\Filament\Resources\AnalyticsDashboardResource\Pages;

use App\Domain\Analytics\Filament\PanelActions;
use App\Filament\Pages\AnalyticsDashboardEditor;
use App\Filament\Resources\AnalyticsDashboardResource;
use App\Models\AnalyticsDashboard;
use Filament\Actions;
use Filament\Resources\Pages\ListRecords;
use Livewire\Attributes\Url;

class ListAnalyticsDashboards extends ListRecords
{
    protected static string $resource = AnalyticsDashboardResource::class;

    #[Url]
    public ?int $add_report = null;

    protected function getHeaderActions(): array
    {
        return [
            AnalyticsDashboardResource::createFolderAction(),
            Actions\CreateAction::make()->label('داشبورد جدید')->modalHeading('ایجاد داشبورد')->modalSubmitActionLabel('ایجاد')->createAnother(false)
                ->using(fn (array $data, $livewire) => app(PanelActions::class)->withForm($livewire->getMountedActionForm(), fn () => app(PanelActions::class)->createDashboard($data)))
                ->successRedirectUrl(fn (AnalyticsDashboard $record) => AnalyticsDashboardEditor::getUrl(array_filter(['record' => $record->id, 'add_report' => $this->add_report]))),
        ];
    }
}
