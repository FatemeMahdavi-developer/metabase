<?php

namespace App\Filament\Resources;

use App\Domain\Analytics\Filament\PanelActions;
use App\Filament\Pages\AnalyticsDatabaseBrowser;
use App\Filament\Resources\AnalyticsConnectionResource\Pages;
use App\Filament\Resources\Concerns\AnalyticsResourceHelpers;
use App\Models\AnalyticsConnection;
use Filament\Forms\Components\Section;
use Filament\Forms\Components\Select;
use Filament\Forms\Components\TextInput;
use Filament\Forms\Components\Toggle;
use Filament\Forms\Form;
use Filament\Forms\Get;
use Filament\Forms\Set;
use Filament\Notifications\Notification;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Validation\ValidationException;

class AnalyticsConnectionResource extends Resource
{
    use AnalyticsResourceHelpers;

    protected static ?string $model = AnalyticsConnection::class;

    protected static ?string $slug = 'analytics/databases';

    protected static ?string $navigationIcon = 'heroicon-o-circle-stack';

    protected static ?string $navigationGroup = 'داشبوردساز';

    protected static ?string $navigationLabel = 'پایگاه‌های داده';

    protected static ?string $modelLabel = 'پایگاه داده';

    protected static ?string $pluralModelLabel = 'پایگاه‌های داده';

    protected static ?string $recordTitleAttribute = 'name';

    protected static ?int $navigationSort = 30;

    protected static string $editorRoute = 'analytics.database-browser';

    public static function getEloquentQuery(): Builder
    {
        return parent::getEloquentQuery()->where('owner_id', static::ownerId());
    }

    public static function form(Form $form): Form
    {
        return $form->schema([
            TextInput::make('name')->label('نام')->required()->maxLength(150)->autofocus(),
            Select::make('driver')->label('نوع پایگاه داده')->options(['sqlite' => 'SQLite', 'pgsql' => 'PostgreSQL', 'clickhouse' => 'ClickHouse'])->required()->default('sqlite')->native()->live()
                ->afterStateUpdated(function (string $state, Set $set): void {
                    $set('configuration', $state === 'sqlite' ? ['path' => ''] : ['host' => 'localhost', 'port' => $state === 'pgsql' ? 5432 : 8123, 'database' => '', 'username' => $state === 'pgsql' ? 'postgres' : 'default', 'ssl' => false, 'sslmode' => 'prefer']);
                }),
            TextInput::make('configuration.path')->label('مسیر فایل SQLite')->required(fn (Get $get) => $get('driver') === 'sqlite')->maxLength(1000)->visible(fn (Get $get) => $get('driver') === 'sqlite')->extraInputAttributes(['dir' => 'ltr'])->helperText('مسیر کامل فایل روی سرور Laravel را وارد کنید.'),
            Section::make('اطلاعات اتصال')->schema([
                TextInput::make('configuration.host')->label('میزبان')->required()->maxLength(200)->extraInputAttributes(['dir' => 'ltr']),
                TextInput::make('configuration.port')->label('پورت')->required()->integer()->minValue(1)->maxValue(65535)->dehydrateStateUsing(fn ($state) => (int) $state)->extraInputAttributes(['dir' => 'ltr']),
                TextInput::make('configuration.database')->label('نام دیتابیس')->required()->maxLength(150)->extraInputAttributes(['dir' => 'ltr']),
                TextInput::make('configuration.username')->label('نام کاربری')->required()->maxLength(150)->extraInputAttributes(['dir' => 'ltr']),
                TextInput::make('configuration.password')->label('رمز عبور')->password()->revealable()->maxLength(500)->autocomplete('new-password')->dehydrated(fn ($state) => filled($state))->helperText('برای حفظ رمز فعلی، این فیلد را خالی بگذارید.'),
                Toggle::make('configuration.ssl')->label('اتصال امن HTTPS')->default(false)->visible(fn (Get $get) => $get('driver') === 'clickhouse'),
                Select::make('configuration.sslmode')->label('حالت SSL')->options(['disable' => 'غیرفعال', 'prefer' => 'ترجیح اتصال امن', 'require' => 'الزام اتصال امن', 'verify-full' => 'بررسی کامل گواهی'])->default('prefer')->visible(fn (Get $get) => $get('driver') === 'pgsql'),
            ])->columns(2)->visible(fn (Get $get) => $get('driver') !== 'sqlite'),
            Toggle::make('test_first')->label('آزمون اتصال پیش از ذخیره')->default(false)->helperText('با فعال‌کردن این گزینه، ذخیره فقط پس از اتصال موفق و خواندن فهرست جدول‌ها انجام می‌شود.'),
        ]);
    }

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                TextColumn::make('name')->label('نام پایگاه داده')->searchable()->sortable()->icon('heroicon-o-circle-stack'),
                TextColumn::make('driver')->label('موتور')->formatStateUsing(fn (string $state) => ['sqlite' => 'SQLite', 'pgsql' => 'PostgreSQL', 'clickhouse' => 'ClickHouse'][$state])->badge(),
                TextColumn::make('status')->label('وضعیت')->getStateUsing(fn (AnalyticsConnection $record) => $record->synced_at ? 'همگام‌شده' : 'نیازمند همگام‌سازی')->badge()->color(fn (AnalyticsConnection $record) => $record->synced_at ? 'success' : 'warning'),
                TextColumn::make('table_count')->label('جدول‌ها')->getStateUsing(fn (AnalyticsConnection $record) => count($record->catalog ?? [])),
                TextColumn::make('synced_at')->label('آخرین همگام‌سازی')->since()->placeholder('هنوز انجام نشده')->sortable(),
            ])
            ->filters([Tables\Filters\SelectFilter::make('driver')->label('موتور')->options(['sqlite' => 'SQLite', 'pgsql' => 'PostgreSQL', 'clickhouse' => 'ClickHouse'])])
            ->recordUrl(fn (AnalyticsConnection $record) => AnalyticsDatabaseBrowser::getUrl(['record' => $record->id]))
            ->actions([
                Tables\Actions\Action::make('browse')->label('مشاهده جدول‌ها')->icon('heroicon-o-table-cells')->url(fn (AnalyticsConnection $record) => AnalyticsDatabaseBrowser::getUrl(['record' => $record->id])),
                Tables\Actions\EditAction::make()->label('ویرایش اتصال')->modalHeading('ویرایش پایگاه داده')->fillForm(fn (AnalyticsConnection $record) => app(PanelActions::class)->connectionFormData($record))
                    ->using(fn (AnalyticsConnection $record, array $data, $livewire) => app(PanelActions::class)->withForm($livewire->getMountedTableActionForm(), fn () => app(PanelActions::class)->saveConnection($data, $record))),
                Tables\Actions\Action::make('test')->label('آزمون اتصال')->icon('heroicon-o-signal')->action(function (AnalyticsConnection $record): void {
                    static::connectionOperation(fn () => app(PanelActions::class)->testConnection($record), 'اتصال برقرار است');
                }),
                Tables\Actions\Action::make('sync')->label('همگام‌سازی')->icon('heroicon-o-arrow-path')->action(function (AnalyticsConnection $record): void {
                    static::connectionOperation(fn () => app(PanelActions::class)->syncConnection($record), 'فهرست جدول‌ها به‌روز شد');
                }),
                Tables\Actions\DeleteAction::make()->label('حذف')->using(fn (AnalyticsConnection $record) => app(PanelActions::class)->withoutForm(fn () => app(PanelActions::class)->deleteConnection($record))),
            ])
            ->defaultSort('name')->emptyStateHeading('هنوز پایگاه داده‌ای اضافه نشده')->emptyStateDescription('یک اتصال SQLite، PostgreSQL یا ClickHouse اضافه کنید.');
    }

    private static function connectionOperation(callable $operation, string $title): void
    {
        try {
            $operation();
            Notification::make()->title($title)->success()->send();
        } catch (ValidationException $exception) {
            Notification::make()->title('اتصال برقرار نشد')->body(collect($exception->errors())->flatten()->first())->danger()->send();
        }
    }

    public static function getPages(): array
    {
        return ['index' => Pages\ListAnalyticsConnections::route('/')];
    }
}
