<?php

namespace App\Filament\Resources;

use App\Domain\Analytics\Filament\PanelActions;
use App\Filament\Pages\AnalyticsReportEditor;
use App\Filament\Resources\AnalyticsReportResource\Pages;
use App\Filament\Resources\Concerns\AnalyticsResourceHelpers;
use App\Models\AnalyticsReport;
use Filament\Forms\Components\Hidden;
use Filament\Forms\Form;
use Filament\Notifications\Notification;
use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Columns\TextColumn;
use Filament\Tables\Table;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\DB;

class AnalyticsReportResource extends Resource
{
    use AnalyticsResourceHelpers;

    protected static ?string $model = AnalyticsReport::class;

    protected static ?string $slug = 'analytics/reports';

    protected static ?string $navigationIcon = 'heroicon-o-chart-bar';

    protected static ?string $navigationGroup = 'داشبوردساز';

    protected static ?string $navigationLabel = 'گزارش‌ها';

    protected static ?string $modelLabel = 'گزارش';

    protected static ?string $pluralModelLabel = 'گزارش‌ها';

    protected static ?string $recordTitleAttribute = 'name';

    protected static ?int $navigationSort = 20;

    protected static string $editorRoute = 'analytics.report-editor';

    public static function getEloquentQuery(): Builder
    {
        return parent::getEloquentQuery()->where('owner_id', static::ownerId());
    }

    public static function form(Form $form): Form
    {
        return $form->schema([...static::metadataSchema(), Hidden::make('version')->required()->rule('integer')]);
    }

    public static function table(Table $table): Table
    {
        $labels = ['table' => 'جدول', 'bar' => 'میله‌ای', 'line' => 'خطی', 'area' => 'ناحیه‌ای', 'pie' => 'دایره‌ای', 'doughnut' => 'دونات', 'number' => 'عدد', 'gauge' => 'گیج', 'scatter' => 'پراکندگی', 'funnel' => 'قیفی', 'progress' => 'پیشرفت', 'pivot' => 'جدول محوری'];
        $displays = collect(config('analytics.displays'))->mapWithKeys(fn (string $display) => [$display => $labels[$display] ?? $display])->all();

        return $table
            ->columns([
                TextColumn::make('name')->label('نام گزارش')->searchable()->sortable()->description(fn (AnalyticsReport $record) => $record->description)->wrap(),
                TextColumn::make('display')->label('نمایش')->formatStateUsing(fn (string $state) => $displays[$state] ?? $state)->badge(),
                TextColumn::make('folder_id')->label('مجموعه')->formatStateUsing(fn ($state) => DB::table('analytics_folders')->where('id', $state)->value('name') ?? 'بدون مجموعه')->placeholder('بدون مجموعه')->toggleable(),
                TextColumn::make('updated_at')->label('آخرین تغییر')->since()->sortable(),
            ])
            ->filters([static::folderFilter(), Tables\Filters\SelectFilter::make('display')->label('نوع نمایش')->options($displays)])
            ->recordUrl(fn (AnalyticsReport $record) => AnalyticsReportEditor::getUrl(['record' => $record->id]))
            ->actions([
                Tables\Actions\Action::make('open')->label('باز کردن')->icon('heroicon-o-pencil-square')->url(fn (AnalyticsReport $record) => AnalyticsReportEditor::getUrl(['record' => $record->id])),
                Tables\Actions\EditAction::make()->label('مشخصات')->modalHeading('ویرایش مشخصات گزارش')
                    ->using(fn (AnalyticsReport $record, array $data, $livewire) => app(PanelActions::class)->withForm($livewire->getMountedTableActionForm(), fn () => app(PanelActions::class)->updateReportMetadata($record, $data))),
                Tables\Actions\Action::make('copy')->label('کپی گزارش')->icon('heroicon-o-document-duplicate')
                    ->visible(fn (AnalyticsReport $record) => $record->owner_id === static::ownerId())
                    ->modalHeading('کپی گزارش')->modalSubmitActionLabel('ایجاد کپی')
                    ->form(static::metadataSchema())
                    ->fillForm(fn (AnalyticsReport $record) => [...$record->only(['description', 'folder_id']), 'name' => mb_substr($record->name, 0, 144).' — کپی'])
                    ->action(function (AnalyticsReport $record, array $data, $livewire): void {
                        $actions = app(PanelActions::class);
                        $copy = $actions->withForm($livewire->getMountedTableActionForm(), fn () => $actions->copyReport($record, $data));
                        Notification::make()->title('کپی گزارش ایجاد شد')->success()->send();
                        $livewire->redirect(AnalyticsReportEditor::getUrl(['record' => $copy->id]));
                    }),
                Tables\Actions\DeleteAction::make()->label('حذف')->using(fn (AnalyticsReport $record) => app(PanelActions::class)->withoutForm(fn () => app(PanelActions::class)->deleteReport($record))),
            ])
            ->defaultSort('updated_at', 'desc')
            ->emptyStateHeading('هنوز گزارشی ندارید')->emptyStateDescription('یک گزارش با ویرایشگر تصویری یا SQL بسازید.');
    }

    public static function getPages(): array
    {
        return ['index' => Pages\ListAnalyticsReports::route('/')];
    }
}
