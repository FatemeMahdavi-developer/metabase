<?php

namespace App\Filament\Pages;

use App\Filament\Resources\AnalyticsConnectionResource;
use App\Filament\Resources\AnalyticsDashboardResource;
use App\Filament\Resources\AnalyticsReportResource;
use Filament\Pages\Page;
use Filament\Support\Enums\MaxWidth;
use Livewire\Attributes\Locked;

abstract class AnalyticsWorkbench extends Page
{
    protected static bool $shouldRegisterNavigation = false;

    protected static string $view = 'filament.pages.analytics-studio';

    #[Locked]
    public string $section = '';

    #[Locked]
    public string $recordId = '';

    public function getHeading(): string
    {
        return '';
    }

    public function getMaxContentWidth(): MaxWidth
    {
        return MaxWidth::Full;
    }

    public function getAnalyticsRoutes(): array
    {
        return [
            'dashboards' => AnalyticsDashboardResource::getUrl(),
            'reports' => AnalyticsReportResource::getUrl(),
            'connections' => AnalyticsConnectionResource::getUrl(),
            'dashboard' => AnalyticsDashboardEditor::getUrl(['record' => '__record__']),
            'report' => AnalyticsReportEditor::getUrl(['record' => '__record__']),
            'browser' => AnalyticsDatabaseBrowser::getUrl(['record' => '__record__']),
        ];
    }

    public function getAnalyticsInitial(): array
    {
        return request()->only(['mode', 'connection', 'table', 'add_report', 'edit', 'intent', 'filters']);
    }

    protected function getViewData(): array
    {
        return [
            'analyticsSection' => $this->section,
            'analyticsRecord' => $this->recordId,
            'analyticsRoutes' => $this->getAnalyticsRoutes(),
            'analyticsInitial' => $this->getAnalyticsInitial(),
        ];
    }
}
