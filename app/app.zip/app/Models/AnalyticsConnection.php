<?php

namespace App\Models;

use App\Domain\Analytics\MetadataLabels;
use Illuminate\Database\Eloquent\Model;

class AnalyticsConnection extends Model
{
    protected $guarded = ['id'];

    protected $hidden = ['configuration'];

    protected function casts(): array
    {
        return ['configuration' => 'encrypted:array', 'catalog' => 'array', 'metadata' => 'array', 'synced_at' => 'datetime'];
    }

    public function publicData(): array
    {
        $configuration = $this->configuration;
        unset($configuration['password']);

        $data = $this->toArray();
        if (is_array($data['catalog'] ?? null)) {
            $data['catalog'] = MetadataLabels::catalog($data['catalog'], $this->metadata ?? []);
        }

        return [...$data, 'configuration' => $configuration, 'has_password' => ! empty($this->configuration['password'])];
    }
}
