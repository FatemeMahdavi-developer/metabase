<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class AnalyticsDashboard extends Model
{
    protected $guarded = ['id'];

    protected function casts(): array
    {
        return ['settings' => 'array'];
    }

    public function canRead(int $userId): bool
    {
        return $this->owner_id === $userId || DB::table('analytics_dashboard_members')->where('dashboard_id', $this->id)->where('user_id', $userId)->exists();
    }

    public function canEdit(int $userId): bool
    {
        return $this->owner_id === $userId || DB::table('analytics_dashboard_members')->where('dashboard_id', $this->id)->where('user_id', $userId)->where('role', 'editor')->exists();
    }
}
