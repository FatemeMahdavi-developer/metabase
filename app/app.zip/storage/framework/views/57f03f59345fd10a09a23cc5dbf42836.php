<?php if (isset($component)) { $__componentOriginal166a02a7c5ef5a9331faf66fa665c256 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-panels::components.page.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-panels::page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/analytics.css', 'resources/js/analytics.js']); ?>
    <div id="analytics-studio" wire:ignore data-api="<?php echo e(url('/analytics/api')); ?>" data-user="<?php echo e(auth()->id()); ?>" data-csrf="<?php echo e(csrf_token()); ?>" data-preview-row-limit="<?php echo e(config('analytics.preview_row_limit')); ?>" data-preview-aggregate-limit="<?php echo e(config('analytics.preview_aggregate_limit')); ?>" data-section="<?php echo e($analyticsSection); ?>" data-record="<?php echo e($analyticsRecord); ?>" data-routes='<?php echo json_encode($analyticsRoutes, 15, 512) ?>' data-initial='<?php echo json_encode($analyticsInitial, 15, 512) ?>'>
        <div data-analytics-content>
            <div class="mb-loading">در حال آماده‌سازی فضای تحلیل…</div>
        </div>
        <?php echo $__env->make('filament.partials.analytics-modal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $attributes = $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $component = $__componentOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?>
<?php /**PATH C:\Users\mahdavi_f\Desktop\pending_updte\app\resources\views/filament/pages/analytics-studio.blade.php ENDPATH**/ ?>