<p
    data-validation-error
    <?php echo e($attributes->class([
            'fi-fo-field-wrp-error-message text-sm text-danger-600 dark:text-danger-400',
        ])); ?>

>
    <?php echo e($slot); ?>

</p>
<?php /**PATH C:\Users\mahdavi_f\Desktop\pending_updte\app\vendor\filament\forms\resources\views/components/field-wrapper/error-message.blade.php ENDPATH**/ ?>