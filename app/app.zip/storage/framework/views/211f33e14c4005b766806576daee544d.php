<h3
    <?php echo e($attributes->class(['fi-section-header-heading text-base font-semibold leading-6 text-gray-950 dark:text-white'])); ?>

>
    <?php echo e($slot); ?>

</h3>
<?php /**PATH C:\Users\mahdavi_f\Desktop\pending_updte\app\vendor\filament\support\resources\views/components/section/heading.blade.php ENDPATH**/ ?>